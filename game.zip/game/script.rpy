﻿# ==============================================================
# "Digitaler Alltag: Mein Jahr im VTSEI"  — EDB-Simulator
# Uses ONLY jump between labels (no call/return anywhere).
#
# CHARAKTERE / BILDER:
#   Tom, Lisa                      -- unverändert
#   Nicola   (Chef, m, Italien)     -- nicola normal.png / nicola coffee.png
#   Brian    (Dev, m, GB)           -- brian normal.png / brian stressed.png
#   Ember    (Dev, nb, Schottland)  -- ember normal.png / ember serious.png
#   Mei Ling (f, China)             -- mei_ling normal.png
#   Baljeet  (m, Indien)            -- baljeet normal.png / baljeet thumbsup.png
#
# HINWEIS ZU BILDDATEIEN:
#   Ren'Py erkennt Bilder automatisch nach dem Muster
#   "<tag> <attribut>.png". "Mei Ling Normal.png" (zwei Leerzeichen)
#   würde falsch aufgeteilt. Datei umbenennen in "mei_ling normal.png".
#
# RÄUME / SCENES:
#   vtsei.jpg          -- Standard-Büro, für die meisten Szenen
#   lernlandschaft.jpg -- Meetings & TikTok-Drehs
#   lounge.jpg          -- Pausen / Kaffeepausen
#
# POSITIONIERUNGS-KONVENTION (einheitlich im ganzen Skript):
#   Nicola: immer "pos_nicola"      -> zoom 0.75, xalign 0.5 (zentriert)
#   Brian:  allein "pos_brian_solo" -> xalign 0.5 (Mitte)
#           mit Ember "pos_brian_paired" -> xalign 5.0 (Original-Wert aus Tag 1)
#   Ember:  allein "pos_ember_solo" -> zoom 0.75, xalign 0.5 (Mitte)
#           mit Brian "pos_ember_paired" -> zoom 0.75, xalign 1.4 (Original-Wert aus Tag 1)
# ==============================================================


# ------------------------------------------------------------
# 0. LANGUAGE SETUP
# ------------------------------------------------------------
init python:
    if persistent.lang is None:
        persistent.lang = "de"

    def t(de, en):
        if persistent.lang == "en":
            return en
        return de

screen language_picker():
    zorder 100
    if main_menu:
        hbox:
            xalign 1.0
            yalign 0.0
            xoffset -20
            yoffset 20
            spacing 10
            textbutton "Deutsch" action SetField(persistent, "lang", "de")
            textbutton "English" action SetField(persistent, "lang", "en")

init python:
    config.always_shown_screens.append("language_picker")


# ------------------------------------------------------------
# 0a. GAME / WINDOW TITLE
# ------------------------------------------------------------
define game_title = "Digitaler Alltag: Mein Jahr im VTSEI"

init python:
    config.name = game_title
    config.version = "0.3"
    build.name = "DigitalerAlltag"

define config.window_title = game_title


# ------------------------------------------------------------
# 0b. CHARACTERS
# ------------------------------------------------------------
define tom = Character("Tom")
define lisa = Character("Lisa")
define boss = Character("Nicola")        # VTSEI-Leiter, männlich, Italien
define dev1 = Character("Brian")         # Mitentwickler, männlich, Grossbritannien
define dev2 = Character("Ember")         # Mitentwickler:in, nicht-binär, Schottland
define mei_ling = Character("Mei Ling")  # weiblich, China
define baljeet = Character("Baljeet")    # männlich, Indien
define p = Character("[player_name]")

default player_name = ""
default player_gender = "m"  # "m", "f" or "nb"


# ------------------------------------------------------------
# 0c. PRONOUN HELPER
# ------------------------------------------------------------
init python:
    def get_pronoun():
        subj = {"m": ("er", "he"), "f": ("sie", "she"), "nb": ("they", "they")}
        obj = {"m": ("ihn", "him"), "f": ("sie", "her"), "nb": ("them", "them")}
        idx = 0 if persistent.lang == "de" else 1
        return subj[player_gender][idx], obj[player_gender][idx]


# ------------------------------------------------------------
# 0d. CHARACTER POSITIONING HELPERS (einheitliche Konvention)
# ------------------------------------------------------------
transform pos_nicola:
    zoom 0.75
    xalign 0.5

transform pos_brian_solo:
    xalign 0.5

transform pos_brian_paired:
    xalign 5.0

transform pos_ember_solo:
    zoom 0.75
    xalign 0.5

transform pos_ember_paired:
    zoom 0.75
    xalign 1.4


# ------------------------------------------------------------
# 0e. DAY / NIGHT SCENE TINTING
# ------------------------------------------------------------
transform tint_morning:
    matrixcolor BrightnessMatrix(0.12) * TintMatrix("#fff7e8")

transform tint_midday:
    matrixcolor IdentityMatrix()

transform tint_evening:
    matrixcolor BrightnessMatrix(-0.18) * TintMatrix("#ffb266")


# ------------------------------------------------------------
# 0f. BIG "DAY X" TITLE AND ENDING ANNOUNCEMENT
# ------------------------------------------------------------
screen day_title_screen(day_num):
    zorder 200
    add "#000000aa"
    text t("TAG [day_num]", "DAY [day_num]"):
        size 90
        xalign 0.5
        yalign 0.5
        color "#ffffff"
        outlines [(3, "#000000", 0, 0)]

screen ending_title_screen(ending_text):
    zorder 200
    add "#000000cc"
    vbox:
        xalign 0.5
        yalign 0.5
        spacing 20
        text t("ENDE", "ENDING"):
            size 64
            xalign 0.5
            color "#ffd700"
            outlines [(3, "#000000", 0, 0)]
        text ending_text:
            size 42
            xalign 0.5
            color "#ffffff"
            text_align 0.5
            xmaximum 950
            outlines [(2, "#000000", 0, 0)]

init python:
    def show_day_title(day_num):
        renpy.show_screen("day_title_screen", day_num=day_num)
        renpy.pause(1.6, hard=True)
        renpy.hide_screen("day_title_screen")

    def show_ending_title(ending_text):
        renpy.show_screen("ending_title_screen", ending_text=ending_text)
        renpy.pause(2.4, hard=True)
        renpy.hide_screen("ending_title_screen")


# ------------------------------------------------------------
# 1. CORE VALUES
# ------------------------------------------------------------
default quality = 50
default speed = 50
default quantity = 50

init python:
    def clamp(value, lo=0, hi=100):
        return max(lo, min(hi, value))

    def adjust_stats(d_quality=0, d_speed=0, d_quantity=0):
        global quality, speed, quantity
        quality = clamp(quality + d_quality)
        if team_working:
            speed = clamp(speed + d_speed)
        quantity = clamp(quantity + d_quantity)


# ------------------------------------------------------------
# 2. PROJECT / TEAM SETUP
# ------------------------------------------------------------
default total_projects = 3
default unsupervised_groups = 2
define PLANNED_WEEKS = 3

default team_working = False
default mockup_chosen = None  # None / True / False

define MOCKUP_QUALITY_BONUS = 10
define MOCKUP_TIME_COST_DAYS = 2

# Planning-phase decisions (Day 2)
default planning_focus = None      # "quality" / "quantity" / "balance"
default planning_reviewed = None   # True / False
default dev_tool = None            # "angular" / "powerapps"

# Day 6 scope-request decision
default scope_request_accepted = None  # True / False

# Small character-arc flag
default ember_supported = False

# Stellt sicher, dass die Kaffeepause mindestens einmal im
# Playthrough vorkommt (spätestens am letzten Montage-Slot vor
# der Deadline, falls sie bis dahin nie zufällig gezogen wurde).
default coffee_break_seen = False


# ------------------------------------------------------------
# 3. TIME SYSTEM
# ------------------------------------------------------------
default current_day = 1
default current_time = 6

define TIME_SLOTS = [6, 8, 10, 12, 14, 16, 18, 20, 22]
define EVENT_SLOT_HOURS = [8, 10, 14, 16]
define FIXED_SLOT_HOURS = [6, 12, 18, 20, 22]
define EVENT_CHANCE = 0.4

default deadline_day = PLANNED_WEEKS * 7
default project_finished = False
default next_label = ""


# ------------------------------------------------------------
# 3a. TIME-OF-DAY TINT HELPER
# ------------------------------------------------------------
init python:
    def time_tint():
        if current_time <= 9:
            return tint_morning
        elif current_time >= 18:
            return tint_evening
        else:
            return tint_midday

    def new_day_scene(bg="vtsei"):
        renpy.scene()
        renpy.show(bg, at_list=[time_tint()])
        show_day_title(current_day)


# ------------------------------------------------------------
# 4. TOP-LEFT DAY/TIME DISPLAY
# ------------------------------------------------------------
screen day_time_display():
    zorder 100
    if not main_menu:
        vbox:
            xalign 0.0
            yalign 0.0
            xoffset 20
            yoffset 20
            text "Tag [current_day]" size 22
            text "[current_time]:00 Uhr" size 22

init python:
    config.overlay_screens.append("day_time_display")


# ------------------------------------------------------------
# 5. SIDE-EVENT POOL
# ------------------------------------------------------------
define SIDE_EVENT_POOL = [
    {"id": "boss_extra_task", "weight": 1, "label": "event_boss_extra_task"},
    {"id": "social_media_tiktok", "weight": 1, "label": "event_social_media_tiktok"},
    {"id": "colleague_needs_help", "weight": 1, "label": "event_colleague_needs_help"},
    {"id": "server_outage", "weight": 1, "label": "event_server_outage"},
    {"id": "printer_jam", "weight": 1, "label": "event_printer_jam"},
    {"id": "client_call", "weight": 1, "label": "event_client_call"},
    {"id": "coffee_break_invite", "weight": 1, "label": "event_coffee_break_invite"},
]

init python:
    import random

    def pick_random_side_event():
        pool = SIDE_EVENT_POOL
        total_weight = sum(e["weight"] for e in pool)
        roll = random.uniform(0, total_weight)
        upto = 0
        for e in pool:
            upto += e["weight"]
            if roll <= upto:
                return e
        return pool[-1]


# ------------------------------------------------------------
# 6. "DOING EXTRA STUFF" PENALTY LOGIC
# ------------------------------------------------------------
default extras_accepted_count = 0

define EXTRA_EVENT_PENALTY = {"quality": -3, "speed": -4, "quantity": -2}

init python:
    def apply_extra_event_penalty():
        global extras_accepted_count
        extras_accepted_count += 1
        scale = 1 + (extras_accepted_count - 1) * 0.1
        adjust_stats(
            d_quality=int(EXTRA_EVENT_PENALTY["quality"] * scale),
            d_speed=int(EXTRA_EVENT_PENALTY["speed"] * scale),
            d_quantity=int(EXTRA_EVENT_PENALTY["quantity"] * scale),
        )

    def apply_decline_event_effect():
        pass


# ------------------------------------------------------------
# 7. PROJECT WORK LOGIC
# ------------------------------------------------------------
define PROJECT_WORK_CHOICES = [
    {"id": "focus_quality", "d_quality": 6, "d_speed": -2, "d_quantity": 0},
    {"id": "focus_speed", "d_quality": -2, "d_speed": 6, "d_quantity": 0},
    {"id": "focus_quantity", "d_quality": -1, "d_speed": -1, "d_quantity": 6},
    {"id": "focus_balance", "d_quality": 2, "d_speed": 2, "d_quantity": 2},
]

init python:
    def apply_project_work_choice(choice_id):
        for choice in PROJECT_WORK_CHOICES:
            if choice["id"] == choice_id:
                adjust_stats(
                    d_quality=choice["d_quality"],
                    d_speed=choice["d_speed"],
                    d_quantity=choice["d_quantity"],
                )
                return
        raise Exception("Unknown project work choice: %s" % choice_id)


# ------------------------------------------------------------
# 7b. TIME-SKIP / MONTAGE LOGIC
# ------------------------------------------------------------
init python:
    def montage_drift(num_days):
        for _ in range(num_days):
            dq = random.randint(-2, 3)
            ds = random.randint(-2, 3) if team_working else 0
            dn = random.randint(-1, 4)
            adjust_stats(d_quality=dq, d_speed=ds, d_quantity=dn)


# ------------------------------------------------------------
# 8. GAME START
# ------------------------------------------------------------
label start:

    scene vtsei
    show tom normal:
        yalign -0.2

    $ tom(t("Hallo! Ich bin Tom.", "Hello! I'm Tom."))
    $ tom(t("Wie heißt du?", "What's your name?"))

    $ player_name = renpy.input(t("Gib deinen Namen ein:", "Enter your name:"), length=20)
    $ player_name = player_name.strip()

    if player_name == "":
        $ player_name = t("Unbekannt", "Unknown")

    $ tom(t("Schön dich kennenzulernen, [player_name]!", "Nice to meet you, [player_name]!"))
    $ tom(t("Wie soll ich dich ansprechen?", "How should I refer to you?"))

    menu:
        "Männlich" if persistent.lang == "de":
            $ player_gender = "m"
        "Male" if persistent.lang == "en":
            $ player_gender = "m"
        "Weiblich" if persistent.lang == "de":
            $ player_gender = "f"
        "Female" if persistent.lang == "en":
            $ player_gender = "f"
        "Nicht-binär" if persistent.lang == "de":
            $ player_gender = "nb"
        "Non-binary" if persistent.lang == "en":
            $ player_gender = "nb"

    $ subj, obj = get_pronoun()

    $ tom(t("Alles klar, ich werde [player_name] als [subj] bezeichnen.", "Got it, I'll refer to [player_name] as [subj]."))

    show tom show:
        xalign -4.0
        yalign -0.3
        xzoom -1

    $ tom(t("Hier befinden wir und im VTSEI, der Abteilung in der wir Informatiker arbeiten.", "We are in the VTSEI, the department where we computer scientists work."))
    $ tom(t("VTSEI steht für Vocational Training System Engineering and Informatics.", "VTSEI stands for Vocational Training System Engineering and Informatics."))

    show tom show:
        xalign 5.0
        xzoom 1.0

    show lisa normal:
        xalign -4.0

    $ tom(t("Das ist Lisa, unsere Social Media Verantwortliche.", "This is Lisa, our social media manager."))
    $ tom(t("Sie ist unter anderem zuständig für Dreh und Uploads von TikToks auf unserem BühlerFuture Account.", "She is responsible for filming and uploading TikToks on our BühlerFuture account, among other things."))
    $ lisa(t("Hallo [player_name], schön dich kennenzulernen!", "Hello [player_name], nice to meet you!"))
    $ lisa(t("Als EDB werden wir dich manchmal für unsere TikTok Videos brauchen, falls wir also mal jemanden brauchen, komme ich wahrscheinlich auf dich zu.", "As EDB, we will sometimes need you for our TikTok videos, so if we ever need someone, I will probably come to you."))

    jump boss_intro


# ------------------------------------------------------------
# 9. BOSS INTRO -> DAY 1
# ------------------------------------------------------------
label boss_intro:
    hide tom
    hide lisa
    show nicola normal:
        pos_nicola

    $ boss(t("Guten Tag, ich bin Nicola, Leiter der VTSEI.", "Good day, I'm Nicola, head of the VTSEI."))
    $ boss(t("Wir haben drei Wochen für die Projekte eingeplant.", "We've planned three weeks for the projects."))
    $ boss(t("Insgesamt stehen drei Projekte an, aber nur eines davon liegt in deiner Verantwortung.", "In total there are three projects, but only one of them is your responsibility."))
    $ boss(t("Die anderen beiden Gruppen kommen ohne Begleitung klar. Am Ende der drei Wochen präsentieren wir alle Ergebnisse vor der Geschäftsleitung -- also soll es sich sehen lassen können.", "The other two groups manage without supervision. At the end of the three weeks we present all results to senior management -- so it should be worth showing."))
    hide nicola
    jump day_1


# ------------------------------------------------------------
# 9b. MOCKUP DECISION (part of the Day 2 planning phase)
# ------------------------------------------------------------
label mockup_decision:
    $ boss(t("Bevor es losgeht: Soll euer Team ein Mockup erstellen?", "Before we start: should your team create a mockup?"))
    $ boss(t("Das dauert länger, aber die Qualität am Ende ist besser.", "It takes longer, but the quality at the end will be better."))

    $ mockup_option_yes = t("Team macht ein Mockup (dauert länger, aber bessere Qualität)", "Team makes a mockup (takes longer, but better quality)")
    $ mockup_option_no = t("Kein Mockup (spart Zeit)", "No mockup (saves time)")

    menu:
        "[mockup_option_yes]":
            $ mockup_chosen = True
            $ deadline_day += MOCKUP_TIME_COST_DAYS
            $ adjust_stats(d_quality=MOCKUP_QUALITY_BONUS)
            $ boss(t("Gute Wahl. Das gibt euch mehr Sicherheit.", "Good choice. That gives you more safety margin."))

        "[mockup_option_no]":
            $ mockup_chosen = False
            $ boss(t("Okay, dann direkt rein in die Umsetzung.", "Okay, straight into implementation then."))

    jump expression next_label


# ------------------------------------------------------------
# 10. DAY 1 — INTRO TO TEAM
# ------------------------------------------------------------
label day_1:
    $ current_day = 1
    $ current_time = 6
    $ team_working = False

    $ new_day_scene()

    $ p(t("Mein erster richtiger Tag als EDB beginnt.", "My first real day as an EDB begins."))
    show tom normal:
        yalign -0.2
    $ tom(t("Komm mit, ich stell dich kurz deinen zwei Entwicklern vor.", "Come on, I'll introduce you to your two developers."))

    show brian normal:
        pos_brian_paired
    show ember normal:
        pos_ember_paired

    $ tom(t("Das sind Brian und Ember. Die beiden entwickeln mit dir zusammen das Projekt -- ihr drei seid ab jetzt ein Team.", "This is Brian and Ember. The two of them will develop the project together with you -- the three of you are a team from now on."))
    $ dev1(t("Freut mich! Bin gespannt, was wir zusammen hinkriegen.", "Nice to meet you! Looking forward to seeing what we can pull off together."))
    $ dev2(t("Willkommen im Team. Wird bestimmt ein spannender Ritt, die drei Wochen.", "Welcome to the team. This'll be quite a ride, these three weeks."))
    $ p(t("Hallo zusammen, ich freue mich auf die Zusammenarbeit.", "Hi everyone, looking forward to working together."))
    $ tom(t("Die anderen zwei Projektgruppen laufen ohne Begleitung -- ihr drei kümmert euch nur um euer eigenes Projekt.", "The other two project groups run without supervision -- the three of you only need to worry about your own project."))

    $ tom(t("Das wird sich morgen alles klären, wenn die Planung beginnt.", "All of that will get sorted out tomorrow when planning starts."))
    hide tom
    hide brian
    hide ember

    jump day_2


# ------------------------------------------------------------
# 11. DAY 2 — PLANNING STARTS (Meeting in der Lernlandschaft)
# ------------------------------------------------------------
label day_2:
    $ current_day = 2
    $ current_time = 6
    $ team_working = True

    $ new_day_scene()

    jump planning_start


label planning_start:
    show nicola normal:
        pos_nicola
    $ boss(t("Guten Morgen! Heute startet die Planungsphase für euer Projekt.", "Good morning! Today the planning phase for your project starts."))
    $ p(t("Verstanden, wir legen los.", "Understood, let's get started."))
    hide nicola

    scene lernlandschaft at time_tint()
    show brian normal:
        pos_brian_paired
    show ember normal:
        pos_ember_paired

    jump planning_team_focus


label planning_team_focus:
    $ p(t("Wir müssen uns jetzt überlegen, wie wir in den 3 Wochen das Projekt rechtzeitig abgeben.", "We need to work out now how we'll get the project in on time within the 3 weeks."))
    $ dev1(t("Ich sage, wir nehmen Qualität, dann ist die App sauber und hat keine Fehler.", "I say we go for quality, then the app will be clean and bug-free."))
    $ dev2(t("Ich sage, wir nehmen Quantität, damit haben die Nutzer mehr Funktionen.", "I say we go for quantity, so users get more features."))
    $ p(t("Nehmen wir lieber...", "Let's rather go with..."))

    $ focus_quality_opt = t("Qualität -- die App wird übersichtlich und stabil, hat aber eher begrenzte Funktionalität.", "Quality -- the app will be clean and stable, but with rather limited functionality.")
    $ focus_quantity_opt = t("Quantität -- die App bekommt mehr Funktionen, wird aber allenfalls unübersichtlicher.", "Quantity -- the app gets more features, but may become less clear.")
    $ focus_balance_opt = t("Am besten versuchen wir beides gleichzeitig, ohne uns ganz zu entscheiden.", "Best if we try to do both at once, without fully committing.")

    menu:
        "[focus_quality_opt]":
            $ planning_focus = "quality"
            $ apply_project_work_choice("focus_quality")
            $ dev1(t("Ja, das klingt gut, wir schauen, dass die App qualitativ gut ist.", "Yes, that sounds good, we'll make sure the app is high quality."))

        "[focus_quantity_opt]":
            $ planning_focus = "quantity"
            $ apply_project_work_choice("focus_quantity")
            $ dev2(t("Also gut, wir schauen, dass die App viele Möglichkeiten hat.", "Alright, we'll make sure the app has plenty of features."))

        "[focus_balance_opt]":
            $ planning_focus = "balance"
            $ apply_project_work_choice("focus_balance")
            $ dev1(t("Ok, wenn wir es so machen wollen.", "Ok, if that's how we want to do it."))

    jump planning_mockup_choice


label planning_mockup_choice:
    show nicola normal:
        pos_nicola
    $ next_label = "planning_tool_choice"
    jump mockup_decision


label planning_tool_choice:
    hide nicola
    $ p(t("Nun müssen wir auswählen, welches Tool wir verwenden sollten. Entweder Angular oder Power Apps, was meint ihr?", "Now we need to pick which tool to use. Either Angular or Power Apps, what do you think?"))
    $ dev1(t("Angular haben wir noch nie verwendet und müssten wir neu lernen. Mit Power Apps ist man aber relativ langsam, wir kennen uns aber damit gut aus.", "We've never used Angular and would have to learn it from scratch. Power Apps is relatively slow, but we know it well."))
    $ p(t("Wie lange bräuchtet ihr, um Angular zu lernen?", "How long would you need to learn Angular?"))
    $ dev2(t("Etwa 1 bis 2 Wochen.", "About 1 to 2 weeks."))
    $ p(t("Wählen wir...", "Let's choose..."))

    $ tool_angular_opt = t("Angular ist die bessere Entscheidung -- obwohl sie es noch nie verwendet haben, holen wir das am Schluss wieder auf.", "Angular is the better choice -- even though they've never used it, we'll catch up by the end.")
    $ tool_powerapps_opt = t("Lieber Power Apps -- eine neue Programmiersprache zu lernen dauert zu lange.", "Better Power Apps -- learning a new language takes too long.")

    menu:
        "[tool_angular_opt]":
            $ dev_tool = "angular"
            $ dev1(t("OK, dann werden wir mal Angular für das Projekt verwenden.", "OK, then we'll use Angular for the project."))

        "[tool_powerapps_opt]":
            $ dev_tool = "powerapps"
            $ dev2(t("Verstanden, Power Apps klingt gut.", "Understood, Power Apps sounds good."))

    $ dev1(t("Wir wären fertig mit der Planung. Was wir noch nicht genau wissen, finden wir in der Entwicklung noch heraus -- zeigen wir unsere Planung mal Nicola.", "We'd be done with planning. Whatever we don't know yet, we'll figure out during development -- let's show Nicola our plan."))
    $ p(t("Wollen wir wirklich schon mit dem Entwickeln anfangen?", "Do we really want to start developing already?"))

    $ review_more_opt = t("Ich finde, wir sollten nochmals alles gut anschauen.", "I think we should take another good look at everything.")
    $ review_rush_opt = t("Ich meine, wenn ihr das sagt, sollten wir schon in die Entwicklung.", "I mean, if you say so, we should already move into development.")

    menu:
        "[review_more_opt]":
            $ planning_reviewed = True
            $ dev1(t("Gut, dann nehmen wir uns noch etwas Zeit, damit später nichts Unklares auftaucht.", "Good, then we'll take some more time so nothing is unclear later."))

        "[review_rush_opt]":
            $ planning_reviewed = False
            $ dev2(t("Passt, dann legen wir direkt los und schauen, was während der Entwicklung noch dazukommt.", "Fine, then we'll dive straight in and see what comes up during development."))

    jump planning_boss_review


label planning_boss_review:
    show nicola normal:
        pos_nicola
    $ p(t("Wir wären mit der Planung fertig, Nicola, hast du Zeit?", "We'd be done with planning, Nicola, do you have a moment?"))
    $ boss(t("Ja, sicher.", "Yes, sure."))

    if planning_focus == "quality":
        $ p(t("Wir schauen auf die Qualität, verwenden [dev_tool], und was wir noch nicht genau wissen, wie wir es machen, finden wir in der Entwicklung noch heraus.", "We're focusing on quality, using [dev_tool], and whatever we don't know yet, we'll figure out during development."))
        $ boss(t("Also, dass ihr auf die Qualität achtet, finde ich gut.", "So, that you're focusing on quality, I like that."))
    elif planning_focus == "quantity":
        $ p(t("Wir schauen auf die Quantität, verwenden [dev_tool], und was wir noch nicht genau wissen, wie wir es machen, finden wir in der Entwicklung noch heraus.", "We're focusing on quantity, using [dev_tool], and whatever we don't know yet, we'll figure out during development."))
        $ boss(t("Also, dass ihr auf möglichst viele Funktionen setzt, ist mutig -- das müsst ihr dann auch sauber umsetzen.", "So, betting on as many features as possible is bold -- you'll need to implement that cleanly too."))
    else:
        $ p(t("Wir versuchen, Qualität und Quantität im Gleichgewicht zu halten, verwenden [dev_tool], und den Rest klären wir während der Entwicklung.", "We're trying to keep quality and quantity balanced, using [dev_tool], and we'll sort out the rest during development."))
        $ boss(t("Ein Mittelweg -- das kann funktionieren, wenn ihr es konsequent durchzieht.", "A middle path -- that can work, if you follow through on it consistently."))

    if mockup_chosen:
        $ boss(t("Gut, dass ihr euch für ein Mockup entschieden habt -- das gibt euch mehr Sicherheit, kostet euch aber auch Zeit.", "Good that you decided on a mockup -- that gives you more safety margin, but it costs you time too."))

    if dev_tool == "angular":
        $ boss(t("Mit Angular hingegen braucht ihr viel zu viel Zeit, um es zu lernen -- das geht nicht.", "Angular, on the other hand, will take you way too long to learn -- that won't work."))

    if not planning_reviewed:
        $ boss(t("Und ihr fangt sicher nicht schon an mit der Entwicklung, wenn ihr noch nicht genau wisst, wie ihr alles macht.", "And you're certainly not starting development yet if you don't even know exactly how you're going to do everything."))

    if dev_tool == "angular" or not planning_reviewed:
        $ p(t("Verstehe, wir werden uns darum kümmern.", "Understood, we'll take care of that."))
        $ p(t("Gehen wir nochmals zu den Auswahlmöglichkeiten.", "Let's go back over the options once more."))

        if dev_tool == "angular":
            $ dev_tool = "powerapps"
            $ adjust_stats(d_speed=-4)
            $ dev2(t("Gut, dann nehmen wir doch Power Apps -- so verlieren wir keine Zeit mehr mit Lernen.", "Fine, we'll go with Power Apps after all -- that way we don't lose more time learning."))

        if not planning_reviewed:
            $ planning_reviewed = True
            $ adjust_stats(d_quality=2, d_speed=-2)
            $ dev1(t("Wir gehen die Planung nochmal in Ruhe durch, bevor wir loslegen.", "We'll go through the plan calmly once more before we start."))

        $ p(t("Perfekt, wir sind jetzt bereit für die Entwicklung.", "Perfect, we're now ready for development."))
    else:
        $ boss(t("Gut, dann könnt ihr direkt loslegen.", "Good, then you can get started right away."))

    hide nicola
    hide brian
    hide ember
    scene vtsei at time_tint()

    $ current_time = 14
    $ next_label = "day2_after_afternoon_slot"
    jump slot_event_or_project


label day2_after_afternoon_slot:
    $ current_time = 17
    jump planning_finished


label planning_finished:
    show nicola normal:
        pos_nicola
    $ boss(t("Gut, die Planung für heute ist abgeschlossen.", "Good, planning for today is done."))
    $ p(t("Dann sehen wir morgen weiter.", "We'll continue tomorrow then."))
    hide nicola
    jump end_of_day


# ------------------------------------------------------------
# 12. EVENT / PROJECT-WORK SLOT HANDLING
# ------------------------------------------------------------
label slot_event_or_project:
    $ roll = random.random()

    if roll < EVENT_CHANCE:
        $ chosen_event = pick_random_side_event()
        jump expression chosen_event["label"]
    else:
        if team_working:
            jump project_work_slot
        else:
            jump idle_slot


label idle_slot:
    $ p(t("Gerade ist nichts zu tun, das Team arbeitet noch nicht am Projekt.", "There's nothing to do right now, the team isn't working on the project yet."))
    jump expression next_label


label project_work_slot:
    $ p(t("Zeit, am Projekt weiterzuarbeiten. Worauf konzentriere ich mich?", "Time to keep working on the project. What should I focus on?"))

    $ choice_quality = t("Auf Qualität achten", "Focus on quality")
    $ choice_speed = t("Schnell vorankommen", "Push forward quickly")
    $ choice_quantity = t("Möglichst viele Features einbauen", "Add as many features as possible")
    $ choice_balance = t("Alles im Gleichgewicht halten", "Keep everything balanced")

    menu:
        "[choice_quality]":
            $ apply_project_work_choice("focus_quality")
            $ p(t("Ich nehme mir Zeit, um es sauber zu machen.", "I take my time to do it cleanly."))

        "[choice_speed]":
            $ apply_project_work_choice("focus_speed")
            $ p(t("Ich versuche, zügig voranzukommen.", "I try to move forward quickly."))

        "[choice_quantity]":
            $ apply_project_work_choice("focus_quantity")
            $ p(t("Ich baue noch ein paar zusätzliche Features ein.", "I add a few extra features."))

        "[choice_balance]":
            $ apply_project_work_choice("focus_balance")
            $ p(t("Ich versuche, an allem ein bisschen zu arbeiten.", "I try to work on a bit of everything."))

    jump expression next_label


# ------------------------------------------------------------
# 13. SIDE-EVENT LABELS
# ------------------------------------------------------------
label event_boss_extra_task:
    show nicola normal:
        pos_nicola
    $ boss(t("Hast du kurz Zeit? Ich bräuchte Hilfe bei etwas anderem.", "Do you have a moment? I could use help with something else."))

    $ choice_help = t("Helfen", "Help out")
    $ choice_decline = t("Ablehnen", "Decline")

    menu:
        "[choice_help]":
            $ apply_extra_event_penalty()
            $ p(t("Klar, ich helfe kurz aus.", "Sure, I'll help out for a bit."))
        "[choice_decline]":
            $ apply_decline_event_effect()
            $ p(t("Tut mir leid, ich muss gerade am Projekt bleiben.", "Sorry, I need to stay focused on the project right now."))

    hide nicola
    jump expression next_label


label event_social_media_tiktok:
    scene lernlandschaft at time_tint()
    show lisa filming

    $ lisa(t("Hey! Wir drehen gleich ein TikTok, hast du kurz Zeit mitzumachen?", "Hey! We're about to film a TikTok, do you have a minute to join?"))

    $ choice_join = t("Mitmachen", "Join in")
    $ choice_decline = t("Ablehnen", "Decline")

    menu:
        "[choice_join]":
            $ apply_extra_event_penalty()
            show lisa thumbsup
            $ p(t("Klar, warum nicht.", "Sure, why not."))
        "[choice_decline]":
            $ apply_decline_event_effect()
            $ p(t("Gerade keine Zeit, sorry.", "No time right now, sorry."))

    scene vtsei at time_tint()
    hide lisa
    jump expression next_label


label event_colleague_needs_help:
    show brian normal:
        pos_brian_solo
    $ dev1(t("Kannst du mir kurz bei etwas helfen? Ich komme gerade nicht weiter.", "Can you help me with something? I'm stuck right now."))

    $ choice_help = t("Helfen", "Help out")
    $ choice_decline = t("Ablehnen", "Decline")

    menu:
        "[choice_help]":
            $ apply_extra_event_penalty()
            $ p(t("Klar, zeig mal her.", "Sure, show me."))
        "[choice_decline]":
            $ apply_decline_event_effect()
            $ p(t("Sorry, ich muss gerade weiterarbeiten.", "Sorry, I need to keep working right now."))

    hide brian
    jump expression next_label


label event_server_outage:
    $ p(t("Auf einmal ist der Server down. Das kostet Zeit.", "Suddenly the server goes down. This costs time."))
    $ adjust_stats(d_speed=-5)
    $ p(t("Nach ein paar Minuten läuft alles wieder.", "After a few minutes, everything is back up."))
    jump expression next_label


label event_printer_jam:
    $ p(t("Der Drucker im Grossraumbüro hat mal wieder einen Papierstau.", "The printer in the open-plan office has jammed again."))

    $ choice_fix = t("Kurz reparieren", "Quickly fix it")
    $ choice_ignore = t("Ignorieren, jemand anderes macht das schon", "Ignore it, someone else will deal with it")

    menu:
        "[choice_fix]":
            $ apply_extra_event_penalty()
            $ p(t("Nach ein paar Minuten Gefummel läuft er wieder.", "After a few minutes of fiddling, it works again."))
        "[choice_ignore]":
            $ apply_decline_event_effect()
            $ p(t("Nicht mein Problem gerade, ich bleibe am Projekt.", "Not my problem right now, I stay on the project."))

    jump expression next_label


label event_client_call:
    show nicola normal:
        pos_nicola
    $ boss(t("Ein Kunde ruft an und hat Fragen zum Projektstand. Kannst du übernehmen?", "A client is calling with questions about project status. Can you take it?"))

    $ choice_take = t("Anruf übernehmen", "Take the call")
    $ choice_pass = t("Weiterleiten an Nicola", "Forward to Nicola")

    menu:
        "[choice_take]":
            $ apply_extra_event_penalty()
            $ p(t("Ich erkläre den aktuellen Stand so gut es geht.", "I explain the current status as best I can."))
        "[choice_pass]":
            $ apply_decline_event_effect()
            $ boss(t("Gut, ich kümmere mich darum.", "Fine, I'll take care of it."))

    hide nicola
    jump expression next_label


label event_coffee_break_invite:
    $ coffee_break_seen = True

    scene lounge at time_tint()
    show lisa normal:
        xalign 0
    show mei ling normal:
        xalign 5.0
    show baljeet normal:
        xalign -4.0

    $ lisa(t("Kaffeepause? Komm doch kurz mit in die Lounge.", "Coffee break? Come join us in the lounge for a bit."))
    $ mei_ling(t("Genau, wir machen gerade eh Pause.", "Exactly, we're taking a break right now anyway."))
    $ baljeet(t("Setz dich zu uns, ein bisschen Kaffee hat noch niemandem geschadet.", "Come sit with us, a little coffee never hurt anyone."))

    $ choice_join = t("Mitkommen", "Join them")
    $ choice_decline = t("Später vielleicht", "Maybe later")

    menu:
        "[choice_join]":
            $ apply_extra_event_penalty()
            show baljeet thumbsup
            $ p(t("Eine kurze Pause tut gut.", "A short break feels good."))

            hide lisa
            show baljeet normal
            show nicola coffee:
                xalign 0.5
                yalign 0.1
            $ boss(t("Ah, auch hier -- guter Kaffee heute, oder?", "Ah, you're here too -- good coffee today, isn't it?"))
            hide nicola

        "[choice_decline]":
            $ apply_decline_event_effect()
            $ p(t("Ich bleibe lieber dran.", "I'd rather keep at it."))

    hide mei_ling
    hide baljeet
    scene vtsei at time_tint()
    jump expression next_label


# ------------------------------------------------------------
# 14. DAY 3 — FIRST FULL WORK DAY
# ------------------------------------------------------------
label day_3:
    $ current_day = 3
    $ current_time = 6
    $ team_working = True

    $ new_day_scene()

    $ p(t("Tag drei. Heute geht die eigentliche Umsetzung richtig los.", "Day three. Today real implementation actually begins."))
    show tom serious
    $ tom(t("Wie fühlst du dich? Bereit für den ersten vollen Arbeitstag?", "How are you feeling? Ready for your first full working day?"))
    $ p(t("Mal schauen, wie der Tag läuft.", "Let's see how the day goes."))
    hide tom

    $ current_time = 8
    $ next_label = "day3_after_morning_slot"
    jump slot_event_or_project

label day3_after_morning_slot:
    $ current_time = 12
    show nicola normal:
        pos_nicola
    $ boss(t("Mittagspause! Wie läuft es bei euch?", "Lunch break! How's it going for you?"))

    $ choice_report_good = t("Ganz gut, wir kommen voran.", "Pretty well, we're making progress.")
    $ choice_report_meh = t("Es könnte besser laufen.", "It could be going better.")

    menu:
        "[choice_report_good]":
            $ boss(t("Schön zu hören, weiter so.", "Good to hear, keep it up."))
        "[choice_report_meh]":
            $ boss(t("Sag Bescheid, falls ihr Unterstützung braucht.", "Let me know if you need support."))
    hide nicola

    $ current_time = 14
    $ next_label = "day3_after_afternoon_slot"
    jump slot_event_or_project

label day3_after_afternoon_slot:
    $ current_time = 22
    $ p(t("Der erste volle Arbeitstag ist geschafft. Anstrengend, aber okay.", "The first full workday is done. Tiring, but okay."))
    jump end_of_day


# ------------------------------------------------------------
# 15. DAY 4 — SIDE-EVENT DAY (3 statt 4 Slots, mit Verbindungstext)
# ------------------------------------------------------------
label day_4:
    $ current_day = 4
    $ current_time = 6
    $ team_working = True

    $ new_day_scene()

    show lisa normal
    $ lisa(t("Guten Morgen! Heute ist bei uns im Büro ordentlich was los, glaub mir.", "Good morning! There's a lot going on in the office today, trust me."))
    $ p(t("Klingt vielversprechend...", "Sounds promising..."))
    hide lisa

    $ current_time = 8
    $ next_label = "day4_slot_2"
    jump slot_event_or_project

label day4_slot_2:
    $ p(t("Kaum erledigt, geht's direkt weiter.", "Barely done, and it's already moving on to the next thing."))
    $ current_time = 12
    $ next_label = "day4_slot_3"
    jump slot_event_or_project

label day4_slot_3:
    $ p(t("So langsam merke ich, was Lisa mit 'ordentlich was los' gemeint hat.", "I'm slowly starting to understand what Lisa meant by 'a lot going on'."))
    $ current_time = 16
    $ next_label = "day4_after_last_slot"
    jump slot_event_or_project

label day4_after_last_slot:
    $ current_time = 22
    $ p(t("Was für ein turbulenter Tag. Morgen wird hoffentlich ruhiger.", "What a turbulent day. Hopefully tomorrow will be calmer."))
    jump end_of_day


# ------------------------------------------------------------
# 16. TAG 5 — KURZE MONTAGE (statt 3-Tage-Block)
# ------------------------------------------------------------
label montage_day5:
    $ current_time = 6
    $ new_day_scene()

    $ p(t("Nach dem turbulenten Vortag beginnt Tag fünf ruhiger.", "After the turbulent day before, day five starts off calmer."))
    show tom normal
    $ tom(t("Wir arbeiten, wir stolpern über die üblichen kleinen Probleme, wir machen weiter.", "We work, we stumble over the usual small problems, we carry on."))
    hide tom

    if mockup_chosen:
        $ p(t("Das Mockup zahlt sich langsam aus -- wir wissen, worauf wir hinarbeiten.", "The mockup is starting to pay off -- we know what we're working towards."))
    else:
        $ p(t("Ohne Mockup improvisieren wir gelegentlich, aber es funktioniert bisher.", "Without a mockup we improvise here and there, but it's working so far."))

    $ montage_drift(1)
    $ current_time = 22

    jump end_of_day


# ------------------------------------------------------------
# 17. TAG 6 — SCOPE-ANFRAGE (echte Szene, keine Montage)
# ------------------------------------------------------------
label day_6:
    $ current_day = 6
    $ current_time = 10
    $ team_working = True

    $ new_day_scene()

    show nicola normal:
        pos_nicola
    $ boss(t("Ich hab gerade mit der Geschäftsleitung telefoniert. Sie hätten gern noch eine zusätzliche Funktion in eurem Projekt.", "I just got off the phone with senior management. They'd like an additional feature added to your project."))
    $ boss(t("Das würde mehr Umfang geben, aber es kostet euch Zeit, die ihr eigentlich nicht habt.", "That would add more scope, but it costs you time you don't really have."))

    show brian normal:
        pos_brian_paired
    show ember normal:
        pos_ember_paired
    $ dev1(t("Mehr Funktionen klingen gut für die Präsentation, aber wir liegen jetzt schon eng im Zeitplan.", "More features sound good for the presentation, but we're already tight on schedule."))
    $ dev2(t("Ich würd sagen, das ist deine Entscheidung -- du kennst den Gesamtstand am besten.", "I'd say that's your call -- you know the overall status best."))

    $ scope_accept_opt = t("Zusatzfunktion annehmen -- mehr Umfang, aber weniger Zeit für den Rest.", "Accept the extra feature -- more scope, but less time for everything else.")
    $ scope_decline_opt = t("Ablehnen -- lieber beim ursprünglichen Plan bleiben.", "Decline -- better to stick with the original plan.")

    menu:
        "[scope_accept_opt]":
            $ scope_request_accepted = True
            $ adjust_stats(d_quantity=8, d_speed=-5)
            $ p(t("Gut, wir nehmen die Zusatzfunktion mit rein.", "Alright, we'll add the extra feature in."))
            $ boss(t("Danke, das wird gut ankommen.", "Thanks, that'll go over well."))
        "[scope_decline_opt]":
            $ scope_request_accepted = False
            $ adjust_stats(d_speed=2)
            $ p(t("Ich denke, wir bleiben lieber beim ursprünglichen Umfang.", "I think we'd rather stick with the original scope."))
            $ boss(t("Verstehe ich. Sicherheit geht vor.", "I understand. Better safe than sorry."))

    hide nicola
    hide brian
    hide ember

    $ current_time = 22
    jump end_of_day


# ------------------------------------------------------------
# 18. TAG 7 — KURZE MONTAGE (statt 3-Tage-Block)
# ------------------------------------------------------------
label montage_day7:
    $ current_time = 6
    $ new_day_scene()

    if scope_request_accepted:
        $ p(t("Die Zusatzfunktion beschäftigt uns noch, aber wir kommen voran.", "The extra feature keeps us busy, but we're making progress."))
    else:
        $ p(t("Ohne die Zusatzfunktion können wir uns ganz auf den ursprünglichen Plan konzentrieren.", "Without the extra feature we can focus entirely on the original plan."))

    $ montage_drift(1)
    $ current_time = 22

    $ p(t("Fast eine Woche ist jetzt vorbei.", "Almost a week has passed now."))
    jump end_of_day


# ------------------------------------------------------------
# 19. DAY 8 — MID-PROJECT CHECK-IN
# ------------------------------------------------------------
label day_8:
    $ current_day = 8
    $ current_time = 6
    $ team_working = True

    $ new_day_scene()

    show nicola normal:
        pos_nicola
    $ boss(t("Wir sind jetzt gut eine Woche unterwegs. Zeit für ein Zwischenfazit.", "We're now a good week into this. Time for a check-in."))
    $ boss(t("Wie steht es um Qualität, Tempo und Umfang eures Projekts?", "How are quality, speed, and scope of your project looking?"))

    $ choice_honest = t("Ehrlich berichten, wo wir stehen.", "Report honestly on where we stand.")
    $ choice_optimistic = t("Optimistisch berichten, um Druck rauszunehmen.", "Report optimistically to take the pressure off.")

    menu:
        "[choice_honest]":
            $ p(t("Ich erzähle ihm ehrlich, wo wir Probleme haben und wo es gut läuft.", "I honestly tell him where we have problems and where things are going well."))
            $ boss(t("Das schätze ich. Ehrlichkeit hilft mir, euch richtig zu unterstützen.", "I appreciate that. Honesty helps me support you properly."))
            $ adjust_stats(d_quality=2)
        "[choice_optimistic]":
            $ p(t("Ich zeichne ein positiveres Bild, als es vielleicht wirklich ist.", "I paint a rosier picture than things maybe really are."))
            $ boss(t("Gut zu hören. Ich verlasse mich darauf, dass das stimmt.", "Good to hear. I'm counting on that being accurate."))
            $ adjust_stats(d_speed=2, d_quantity=-2)
    hide nicola

    $ current_time = 10
    $ next_label = "day8_after_morning_slot"
    jump slot_event_or_project

label day8_after_morning_slot:
    $ current_time = 14
    show ember serious:
        pos_ember_solo
    $ dev2(t("Ehrlich gesagt bin ich gerade ziemlich im Stress mit dem Ganzen.", "Honestly, I'm pretty stressed with everything right now."))

    $ ember_support_opt = t("Ember beruhigen und kurz zuhören.", "Reassure Ember and listen for a moment.")
    $ ember_move_on_opt = t("Kurz nicken und weitermachen.", "Nod briefly and move on.")

    menu:
        "[ember_support_opt]":
            $ ember_supported = True
            $ adjust_stats(d_quality=1)
            $ p(t("Hey, das schaffen wir zusammen. Sag einfach, wenn's zu viel wird.", "Hey, we'll get through this together. Just say something if it gets to be too much."))
            $ dev2(t("Danke, das hilft wirklich.", "Thanks, that actually helps."))
        "[ember_move_on_opt]":
            $ p(t("Kopf hoch, wir kriegen das hin.", "Chin up, we'll get it done."))
    hide ember

    show tom serious
    $ tom(t("Wie fühlt sich das Projekt für dich gerade an, ehrlich?", "How does the project feel for you right now, honestly?"))

    $ choice_stressed = t("Ehrlich gesagt etwas stressig.", "Honestly, a bit stressful.")
    $ choice_fine = t("Eigentlich ganz gut im Griff.", "Actually feels pretty under control.")

    menu:
        "[choice_stressed]":
            $ tom(t("Das kenne ich. Nimm dir zwischendurch ruhig eine Pause.", "I know that feeling. Feel free to take a break here and there."))
        "[choice_fine]":
            $ tom(t("Schön zu hören, dann bleib einfach am Ball.", "Good to hear, then just keep at it."))
    hide tom

    $ next_label = "day8_after_afternoon_slot"
    jump slot_event_or_project

label day8_after_afternoon_slot:
    $ current_time = 22
    $ p(t("Ein Tag mit ehrlichem Blick auf den Fortschritt -- gut so.", "A day with an honest look at progress -- good."))
    jump end_of_day


# ------------------------------------------------------------
# 20. MONTAGE: DAYS 9-11
# ------------------------------------------------------------
label montage_9_to_11:
    $ current_time = 6
    $ new_day_scene()

    $ p(t("Die zweite Woche zieht sich hin, aber die Routine hilft.", "The second week drags on, but the routine helps."))
    show lisa normal
    $ lisa(t("Ihr seid echt fleissig -- ich hab kaum von euch gehört, weil ihr so beschäftigt seid.", "You've been really diligent -- I've barely heard from you because you're so busy."))
    hide lisa

    $ montage_drift(3)
    # current_day wird von end_of_day gleich noch +1 gerechnet --
    # deshalb hier nur +2, sonst würde Tag 12 übersprungen.
    $ current_day += 2
    $ current_time = 22

    # Garantie: Falls die Kaffeepause bis hierhin noch nie
    # zufällig vorgekommen ist, holen wir sie an dieser Stelle nach,
    # damit sie mindestens einmal im Spielverlauf auftaucht.
    if not coffee_break_seen:
        jump event_coffee_break_guaranteed

    $ p(t("Fast zwei Wochen sind jetzt vorbei. Die Deadline rückt näher.", "Almost two weeks are over now. The deadline is getting closer."))
    jump end_of_day


label event_coffee_break_guaranteed:
    $ next_label = "montage_9_to_11_after_coffee"
    jump event_coffee_break_invite

label montage_9_to_11_after_coffee:
    $ p(t("Fast zwei Wochen sind jetzt vorbei. Die Deadline rückt näher.", "Almost two weeks are over now. The deadline is getting closer."))
    jump end_of_day


# ------------------------------------------------------------
# 21. DAY 12 — CRUNCH DAY
# ------------------------------------------------------------
label day_12:
    $ current_day = 12
    $ current_time = 6
    $ team_working = True

    $ new_day_scene()

    show nicola normal:
        pos_nicola
    $ boss(t("Wir nähern uns der zweiten Hälfte der Projektzeit. Jetzt zählt jeder Tag.", "We're approaching the second half of the project time. Every day counts now."))
    $ p(t("Verstanden. Ich gebe nochmal richtig Gas.", "Understood. I'll really push now."))
    hide nicola

    show brian stressed:
        pos_brian_solo
    $ dev1(t("Puh, es wird gerade ziemlich eng, aber wir schaffen das schon.", "Ugh, it's getting pretty tight, but we'll manage."))
    hide brian

    show ember normal:
        pos_ember_solo
    if ember_supported:
        $ dev2(t("Danke nochmal, dass du letzte Woche für mich da warst -- das gibt mir gerade echt Kraft.", "Thanks again for being there for me last week -- it's really giving me strength right now."))
    else:
        $ dev2(t("Wird schon irgendwie klappen, so wie immer.", "It'll work out somehow, like it always does."))
    hide ember

    $ current_time = 8
    $ next_label = "day12_slot_2"
    jump slot_event_or_project

label day12_slot_2:
    $ current_time = 10
    show lisa normal
    $ lisa(t("Wir brauchen dringend jemanden fürs nächste TikTok, es ist ziemlich kurzfristig.", "We urgently need someone for the next TikTok, it's pretty short notice."))
    $ p(t("Gerade jetzt? Wir stecken mitten in der Umsetzung.", "Right now? We're right in the middle of implementation."))

    $ choice_help_lisa = t("Trotzdem helfen -- Lisa im Stich lassen fühlt sich falsch an.", "Help anyway -- leaving Lisa hanging feels wrong.")
    $ choice_stay_focused = t("Ablehnen und am Projekt bleiben.", "Decline and stay on the project.")

    menu:
        "[choice_help_lisa]":
            $ apply_extra_event_penalty()
            scene lernlandschaft at time_tint()
            show lisa filming
            show lisa thumbsup
            $ lisa(t("Danke dir, das rette ich mir gut.", "Thanks, you're a lifesaver."))
            scene vtsei at time_tint()
        "[choice_stay_focused]":
            $ apply_decline_event_effect()
            $ lisa(t("Kein Problem, ich frage jemand anderen.", "No problem, I'll ask someone else."))
    hide lisa

    $ current_time = 14
    $ next_label = "day12_after_afternoon_slot"
    jump slot_event_or_project

label day12_after_afternoon_slot:
    $ current_time = 22
    show tom normal
    $ tom(t("Guter Einsatz heute. Ich merke, dass du reingewachsen bist.", "Good effort today. I can tell you've grown into this."))
    $ p(t("Danke, das bedeutet mir viel.", "Thanks, that means a lot."))
    hide tom
    jump end_of_day


# ------------------------------------------------------------
# 22. MONTAGE: FINAL STRETCH (variable length)
# ------------------------------------------------------------
label montage_final_stretch:
    $ days_left = deadline_day - current_day - 1
    if days_left < 1:
        $ days_left = 1

    $ current_time = 6
    $ new_day_scene()

    $ p(t("Die letzten Tage vor der Abgabe verschwimmen zu einem einzigen Blur aus Arbeit.", "The last days before the deadline blur into a single stretch of work."))
    show nicola normal:
        pos_nicola
    $ boss(t("Endspurt! Bringt es zu Ende.", "Final stretch! Bring it home."))
    hide nicola

    $ montage_drift(days_left)
    $ current_day += days_left
    $ current_time = 22

    $ p(t("Und dann, praktisch über Nacht, ist es plötzlich der letzte Tag.", "And then, almost overnight, it's suddenly the last day."))
    jump end_of_day


# ------------------------------------------------------------
# 23. FINAL DAY — LAST PUSH BEFORE SUBMISSION
# ------------------------------------------------------------
label day_final:
    $ current_time = 6
    $ team_working = True

    $ new_day_scene()

    $ p(t("Heute ist der Tag. Die Abgabe steht bevor.", "Today is the day. The submission is coming up."))
    show tom show
    $ tom(t("Letzte Chance für Feinschliff. Was machst du noch?", "Last chance for polish. What are you doing with it?"))

    $ choice_polish = t("Letzte Details polieren.", "Polish the final details.")
    $ choice_push_features = t("Noch schnell ein Feature reinquetschen.", "Squeeze in one more feature.")
    $ choice_rest = t("Nichts mehr riskieren, so lassen wie es ist.", "Not risk anything, leave it as is.")

    menu:
        "[choice_polish]":
            $ apply_project_work_choice("focus_quality")
        "[choice_push_features]":
            $ apply_project_work_choice("focus_quantity")
        "[choice_rest]":
            $ p(t("Ich lasse es, wie es ist, und atme kurz durch.", "I leave it as it is, and take a breath."))
    hide tom

    $ current_time = 12
    show nicola normal:
        pos_nicola
    $ boss(t("Wie steht ihr da, kurz vor Schluss?", "How are you looking, right before the end?"))
    $ p(t("Wir sind bereit, so gut es geht.", "We're as ready as we can be."))
    hide nicola

    jump project_submission


# ------------------------------------------------------------
# 14b. END OF DAY / DEADLINE CHECK
# ------------------------------------------------------------
label end_of_day:
    $ current_day += 1

    if quantity >= 100:
        $ project_finished = True

    if current_day > deadline_day or project_finished:
        jump project_submission
    elif current_day == 3:
        jump day_3
    elif current_day == 4:
        jump day_4
    elif current_day == 5:
        jump montage_day5
    elif current_day == 6:
        jump day_6
    elif current_day == 7:
        jump montage_day7
    elif current_day == 8:
        jump day_8
    elif current_day in (9, 10, 11):
        jump montage_9_to_11
    elif current_day == 12:
        jump day_12
    elif current_day >= deadline_day - 1:
        jump day_final
    else:
        jump montage_final_stretch


# ------------------------------------------------------------
# 15. PROJECT SUBMISSION + ENDING CALCULATION
# ------------------------------------------------------------
label project_submission:
    show nicola normal:
        pos_nicola
    $ boss(t("So, die Zeit ist um. Zeig mir, was ihr geschafft habt.", "Alright, time's up. Show me what you've accomplished."))
    $ p(t("Hier ist unser Ergebnis.", "Here's our result."))
    jump calculate_ending


init python:
    def get_speed_axis():
        if speed >= 70:
            return "fast"
        elif speed >= 40:
            return "normal"
        else:
            return "slow"

    def get_quality_axis():
        if quality >= 70:
            return "good"
        elif quality >= 40:
            return "medium"
        else:
            return "bad"

    def get_quantity_axis():
        if quantity >= 70:
            return "many_features"
        elif quantity >= 40:
            return "some_features"
        else:
            return "few_features"

    def get_ending_key():
        return "%s_%s_%s" % (
            get_speed_axis(),
            get_quality_axis(),
            get_quantity_axis(),
        )

label calculate_ending:
    $ ending_key = get_ending_key()

    if ending_key == "fast_good_many_features":
        jump ending_fast_good_many
    elif ending_key == "fast_good_some_features":
        jump ending_fast_good_some
    elif ending_key == "fast_good_few_features":
        jump ending_fast_good_few
    elif ending_key == "fast_medium_many_features":
        jump ending_fast_medium_many
    elif ending_key == "fast_bad_many_features":
        jump ending_fast_bad_many
    elif ending_key == "slow_good_many_features":
        jump ending_slow_good_many
    elif ending_key == "slow_good_few_features":
        jump ending_slow_good_few
    elif ending_key == "slow_bad_few_features":
        jump ending_slow_bad_few
    else:
        jump ending_generic


# ------------------------------------------------------------
# 24. ENDINGS
# ------------------------------------------------------------

label ending_fast_good_many:
    $ boss(t("Das ist... beeindruckend. Schnell, sauber, und vollständig.", "This is... impressive. Fast, clean, and complete."))
    $ boss(t("Ehrlich gesagt hätte ich das von einem Team in dieser Zeit nicht erwartet.", "Honestly, I didn't expect this from a team in this amount of time."))
    hide nicola
    show tom normal
    $ tom(t("Du hast das wirklich gerissen. Respekt.", "You really nailed this. Respect."))
    hide tom
    $ show_ending_title(t("Der Musterschüler -- alles lief perfekt zusammen.", "The Model Student -- everything came together perfectly."))
    return


label ending_fast_good_some:
    $ boss(t("Solide Arbeit. Schnell und mit guter Qualität, auch wenn nicht alles Geplante drin ist.", "Solid work. Fast and with good quality, even if not everything planned made it in."))
    $ p(t("Wir haben Prioritäten gesetzt, und ich glaube, es war die richtige Wahl.", "We set priorities, and I think it was the right call."))
    hide nicola
    $ show_ending_title(t("Effizient und sauber -- ein gutes Ergebnis mit klugen Kompromissen.", "Efficient and Clean -- a good result with smart compromises."))
    return


label ending_fast_good_few:
    $ boss(t("Was ihr abgeliefert habt ist klein, aber wirklich gut gemacht.", "What you delivered is small, but really well made."))
    hide nicola
    show tom normal
    $ tom(t("Manchmal ist weniger mehr, oder?", "Sometimes less is more, right?"))
    hide tom
    $ show_ending_title(t("Klein, aber fein -- Qualität über Umfang.", "Small but Excellent -- quality over scope."))
    return


label ending_fast_medium_many:
    $ boss(t("Ihr wart schnell und habt viel geschafft, auch wenn die Qualität stellenweise wackelt.", "You were fast and got a lot done, even if quality wobbles in places."))
    $ p(t("Wir wissen, wo die Schwachstellen sind. Die hätten wir mit mehr Zeit ausgebügelt.", "We know where the weak spots are. We'd have ironed those out with more time."))
    hide nicola
    $ show_ending_title(t("Viel geschafft, aber mit Kanten -- ein funktionales, aber ungeschliffenes Ergebnis.", "A Lot Done, but Rough Edges -- a functional but unpolished result."))
    return


label ending_fast_bad_many:
    $ boss(t("Ihr wart schnell und habt viele Features reingepackt... aber die Qualität leidet deutlich.", "You were fast and packed in a lot of features... but quality clearly suffers."))
    hide nicola
    show tom normal
    $ tom(t("Ich glaube, das rächt sich später, wenn jemand das wirklich benutzen will.", "I think this comes back to bite us later, once someone actually tries to use it."))
    hide tom
    $ show_ending_title(t("Quantität um jeden Preis -- viel Show, wenig Substanz.", "Quantity at Any Cost -- lots of show, little substance."))
    return


label ending_slow_good_many:
    $ boss(t("Es hat länger gedauert als geplant, aber was ihr abliefert ist umfangreich und wirklich gut.", "It took longer than planned, but what you're delivering is extensive and really good."))
    $ p(t("Wir haben uns die Zeit genommen, die es gebraucht hat.", "We took the time it needed."))
    hide nicola
    $ show_ending_title(t("Gründlich bis zum Schluss -- Perfektion hat ihren Preis, aber sie hat sich gelohnt.", "Thorough to the End -- perfection had its price, but it paid off."))
    return


label ending_slow_good_few:
    if mockup_chosen:
        $ boss(t("Ihr wart gründlich mit dem Mockup, aber am Ende ist wenig fertig geworden.", "You were thorough with the mockup, but little ended up finished."))
    else:
        $ boss(t("Es ist wenig fertig geworden, aber was da ist, ist solide gemacht.", "Little got finished, but what's there is solidly made."))
    hide nicola
    show tom normal
    $ tom(t("Qualität war euch wichtiger als Tempo. Das sieht man.", "Quality mattered more to you than speed. It shows."))
    hide tom
    $ show_ending_title(t("Der Perfektionist -- lieber wenig, aber richtig.", "The Perfectionist -- better little, but done right."))
    return


label ending_slow_bad_few:
    $ boss(t("Das... war leider keine gute Projektphase. Wenig fertig, und auch die Qualität stimmt nicht.", "That... was unfortunately not a good project phase. Little finished, and the quality isn't there either."))
    $ boss(t("Wir müssen ernsthaft besprechen, was hier schiefgelaufen ist.", "We need to seriously discuss what went wrong here."))
    hide nicola
    show tom normal
    $ tom(t("Hey, das war ein harter Start. Beim nächsten Projekt wird's besser.", "Hey, that was a rough start. It'll go better on the next project."))
    hide tom
    $ show_ending_title(t("Der harte Weg -- ein schwerer Rückschlag, aber eine Lektion fürs nächste Mal.", "The Hard Way -- a tough setback, but a lesson for next time."))
    return


label ending_generic:
    $ boss(t("Nun, das Ergebnis ist gemischt -- nicht überragend, aber auch nicht katastrophal.", "Well, the result is mixed -- not outstanding, but not a disaster either."))
    $ p(t("Wir haben getan, was wir konnten mit der Zeit und den Entscheidungen, die wir getroffen haben.", "We did what we could with the time and the decisions we made."))
    hide nicola
    $ show_ending_title(t("Mittelmass -- ein Projekt wie viele andere, weder Glanzstück noch Reinfall.", "Middle of the Road -- a project like many others, neither a showpiece nor a flop."))
    return
