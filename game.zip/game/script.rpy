init python:
    if persistent.lang is None:
        persistent.lang = "de"

    def t(de, en):
        if persistent.lang == "en":
            return en
        return de

screen language_picker():
    zorder 100
    if main_menu and not renpy.get_screen("how_to_play"):
        hbox:
            xalign 1.0
            yalign 0.0
            xoffset -20
            yoffset 20
            spacing 10
            textbutton "Deutsch" action SetField(persistent, "lang", "de")
            textbutton "English" action SetField(persistent, "lang", "en")

init python:
    config.always_shown_screens.append("language_picker")


define game_title = "EDB: Projektmanagement"

define config.window_title = game_title

define config.rollback_enabled = True

init python:
    _blocked_binds = ("mousedown_3", "mouseup_3", "mousedown_4", "mouseup_4", "mousedown_5", "mouseup_5")
    for _keymap_name in list(config.keymap.keys()):
        config.keymap[_keymap_name] = [
            _bind for _bind in config.keymap[_keymap_name] if _bind not in _blocked_binds
        ]

    config.keymap["dismiss"] = ["mouseup_1", "K_RETURN", "K_SPACE"]
    config.keymap["dismiss_hard_pause"] = []


init python:
    def make_name(de_name, de_role, en_name, en_role):
        return t("%s (%s)" % (de_name, de_role), "%s (%s)" % (en_name, en_role))

define tom = Character(make_name("Tom", "Mitlernender", "Tom", "Apprentice"))
define lisa = Character(make_name("Lisa", "Hauptansprechsperson", "Lisa", "Main Contact"))
define boss = Character(make_name("Nicola", "Abteilungsleiter", "Nicola", "Head of Department"))
define dev1 = Character(make_name("Brian", "Entwicklung", "Brian", "Development"))
define dev2 = Character(make_name("Ember", "Entwicklung", "Ember", "Development"))
define meiling = Character(make_name("Mei Ling", "Kollegin", "Mei Ling", "Colleague"))
define baljeet = Character(make_name("Baljeet", "Kollege", "Baljeet", "Colleague"))
define p = Character("[player_name]")

default player_name = ""


transform pos_nicola:
    zoom 0.75
    xalign 0.5

transform pos_brian_solo:
    xalign 0.5

transform pos_brian_paired:
    xalign 5.0

transform pos_ember_solo:
    zoom 0.75
    xalign 0.5

transform pos_ember_paired:
    zoom 0.75
    xalign 1.4


transform tint_morning:
    matrixcolor BrightnessMatrix(0.12) * TintMatrix("#fff7e8")

transform tint_midday:
    matrixcolor IdentityMatrix()

transform tint_evening:
    matrixcolor BrightnessMatrix(-0.18) * TintMatrix("#ffb266")


screen day_title_screen(day_num):
    zorder 200
    add "#000000aa"
    text t("TAG [day_num]", "DAY [day_num]"):
        size 90
        xalign 0.5
        yalign 0.5
        color "#ffffff"
        outlines [(3, "#000000", 0, 0)]


screen ending_title_screen(ending_name, ending_text):
    zorder 200
    add "#000000dd"

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 26

        text t("PROJEKT ABGESCHLOSSEN", "PROJECT COMPLETE"):
            size 24
            xalign 0.5
            color "#a8a49c"
            outlines [(1, "#000000", 0, 0)]

        text ending_name:
            size 58
            xalign 0.5
            color "#ffd700"
            text_align 0.5
            xmaximum 950
            outlines [(3, "#000000", 0, 0)]

        add Solid("#ffd700") xsize 320 ysize 2 xalign 0.5

        text ending_text:
            size 34
            xalign 0.5
            color "#ffffff"
            text_align 0.5
            xmaximum 900
            outlines [(2, "#000000", 0, 0)]

        hbox:
            xalign 0.5
            spacing 50

            vbox:
                xsize 180
                spacing 4
                text t("Qualität", "Quality") size 20 color "#a8a49c" xalign 0.5
                bar value AnimatedValue(quality, 100, delay=0.8) xsize 170 ysize 16 xalign 0.5
                text "[quality]/100" size 18 color "#ffffff" xalign 0.5

            vbox:
                xsize 180
                spacing 4
                text t("Tempo", "Speed") size 20 color "#a8a49c" xalign 0.5
                bar value AnimatedValue(speed, 100, delay=0.8) xsize 170 ysize 16 xalign 0.5
                text "[speed]/100" size 18 color "#ffffff" xalign 0.5

            vbox:
                xsize 180
                spacing 4
                text t("Umfang", "Scope") size 20 color "#a8a49c" xalign 0.5
                bar value AnimatedValue(quantity, 100, delay=0.8) xsize 170 ysize 16 xalign 0.5
                text "[quantity]/100" size 18 color "#ffffff" xalign 0.5

        textbutton t("Neu starten", "Restart"):
            xalign 0.5
            action Return()
            text_size 30
            text_color "#ffffff"
            text_hover_color "#ffd700"
            padding (20, 10)
            background "#00000099"
            hover_background "#ffd70055"

init python:
    def show_day_title(day_num):
        renpy.show_screen("day_title_screen", day_num=day_num)
        renpy.pause(1.6, hard=True)
        renpy.hide_screen("day_title_screen")

    def show_ending_title(ending_text):
        if " -- " in ending_text:
            ending_name, ending_body = ending_text.split(" -- ", 1)
        else:
            ending_name, ending_body = "", ending_text
        renpy.transition(dissolve)
        renpy.call_screen("ending_title_screen", ending_name=ending_name, ending_text=ending_body)



screen stat_toast(msg):
    zorder 250
    frame:
        xalign 0.0
        yalign 1.0
        xoffset 20
        yoffset -20
        padding (14, 8)
        background "#000000cc"
        text msg:
            size 18
            color "#ffd700"
            outlines [(1, "#000000", 0, 0)]
    timer 5.0 action Hide("stat_toast")

init python:
    def show_stat_toast(msg):
        renpy.hide_screen("stat_toast")
        renpy.show_screen("stat_toast", msg=msg)


default quality = 50
default speed = 50
default quantity = 50

define HIGH_STAT_WARNING_THRESHOLD = 80

init python:
    def clamp(value, lo=0, hi=100):
        return max(lo, min(hi, value))

    def adjust_stats(d_quality=0, d_speed=0, d_quantity=0, show_toast=True):
        global quality, speed, quantity
        old_q, old_s, old_n = quality, speed, quantity

        quality = clamp(quality + d_quality)
        if team_working:
            speed = clamp(speed + d_speed)
        quantity = clamp(quantity + d_quantity)
        if team_working and d_speed < 0:
            check_deadline_extension()

        if show_toast:
            real_dq = quality - old_q
            real_ds = speed - old_s
            real_dn = quantity - old_n
            parts = []
            if real_dq:
                parts.append(t("Qualität %+d" % real_dq, "Quality %+d" % real_dq))
            if real_ds:
                parts.append(t("Tempo %+d" % real_ds, "Speed %+d" % real_ds))
            if real_dn:
                parts.append(t("Umfang %+d" % real_dn, "Scope %+d" % real_dn))
            if parts:
                show_stat_toast(" | ".join(parts))

    def check_deadline_extension():
        global deadline_day, deadline_extended_stage
        if speed < 15 and deadline_extended_stage < 2:
            deadline_day += 1
            deadline_extended_stage = 2
        elif speed < 30 and deadline_extended_stage < 1:
            deadline_day += 1
            deadline_extended_stage = 1

    def get_high_stat_warning():
        if quality >= HIGH_STAT_WARNING_THRESHOLD and speed < 50 and quantity < 50:
            return t(
                "Die Qualität ist schon sehr hoch -- vielleicht lohnt es sich, auch mal Tempo oder Umfang mehr Beachtung zu schenken?",
                "Quality is already very high -- maybe it's worth paying more attention to speed or scope for a change?"
            )
        if speed >= HIGH_STAT_WARNING_THRESHOLD and quality < 50 and quantity < 50:
            return t(
                "Beim Tempo seid ihr schon top unterwegs -- wie wäre es, auch mal auf Qualität oder Umfang zu achten?",
                "You're already flying on speed -- how about paying some attention to quality or scope too?"
            )
        if quantity >= HIGH_STAT_WARNING_THRESHOLD and quality < 50 and speed < 50:
            return t(
                "Ihr habt schon sehr viele Funktionen eingebaut -- willst du nicht auch mal etwas auf die Qualität achten?",
                "You've already packed in a lot of features -- want to pay some attention to quality for a change?"
            )
        return None

    def maybe_show_high_stat_warning():
        warning = get_high_stat_warning()
        if warning:
            p(warning)


define PLANNED_WEEKS = 3

default team_working = False
default draft_chosen = None

define DRAFT_QUALITY_BONUS = 10
define DRAFT_TIME_COST_DAYS = 2

default planning_focus = None
default planning_reviewed = None
default dev_tool = None

init python:
    def tool_display_name(dev_tool_val):
        if dev_tool_val == "angular":
            return t("das neue Tool", "the new tool")
        else:
            return t("das bekannte Tool", "the familiar tool")

default scope_request_accepted = None

default ember_supported = False

default coffee_break_seen = False


default current_day = 1
default current_time = 8
default day_display_active = False

define TIME_SLOTS = [8, 9, 10, 12, 13, 14, 15, 16, 17, 18]
define EVENT_SLOT_HOURS = [9, 10, 13, 14]
define FIXED_SLOT_HOURS = [8, 12, 16, 17, 18]
define EVENT_CHANCE = 0.4
define MAX_RANDOM_EVENTS = 3

default deadline_day = PLANNED_WEEKS * 7
default project_finished = False
default next_label = ""
default deadline_extended_stage = 0
default random_events_triggered = 0
default seen_random_event_ids = []


init python:
    def time_tint():
        if current_time <= 9:
            return tint_morning
        elif current_time >= 16:
            return tint_evening
        else:
            return tint_midday

    def new_day_scene(bg="vtsei"):
        global day_display_active
        renpy.scene()
        renpy.show(bg, at_list=[time_tint()])
        day_display_active = False
        show_day_title(current_day)
        day_display_active = True


screen day_time_display():
    zorder 100
    if not main_menu and not renpy.get_screen("how_to_play") and day_display_active:
        frame:
            xalign 0.0
            yalign 0.0
            xoffset 20
            yoffset 20
            padding (16, 10)
            background "#000000aa"
            vbox:
                spacing 2
                text "Tag [current_day]" size 22 color "#ffffff" outlines [(2, "#000000", 0, 0)]
                text "[current_time]:00 Uhr" size 22 color "#ffffff" outlines [(2, "#000000", 0, 0)]

init python:
    config.overlay_screens.append("day_time_display")


screen main_menu():
    tag menu

    add "vtsei" at tint_evening

    add "#00000088"

    vbox:
        xalign 0.5
        yalign 0.16
        spacing 4

        text "EDB" size 110 xalign 0.5 color "#ffd700" outlines [(4, "#000000", 0, 0)]
        text t("PROJEKTMANAGEMENT", "PROJECT MANAGEMENT") size 34 xalign 0.5 color "#ffffff" outlines [(3, "#000000", 0, 0)]

    frame:
        xalign 0.5
        yalign 0.72
        background None
        vbox:
            spacing 14
            xalign 0.5

            textbutton t("Spielen", "Play") action Start() style "main_menu_button"
            textbutton t("Anleitung", "How to Play") action Show("how_to_play") style "main_menu_button"
            textbutton t("Beenden", "Quit") action Quit(confirm=not main_menu) style "main_menu_button"

style main_menu_button:
    xalign 0.5
    xsize 320
    padding (20, 12)
    background "#00000099"
    hover_background "#ffd70055"

style main_menu_button_text:
    size 30
    color "#ffffff"
    hover_color "#ffd700"
    xalign 0.5
    outlines [(2, "#000000", 0, 0)]

screen how_to_play():
    zorder 300
    modal True

    add "#000000cc"

    frame:
        xalign 0.5
        yalign 0.5
        padding (44, 34)
        background "#111111ee"

        vbox:
            spacing 22
            xsize 620

            text t("Anleitung", "How to Play") size 40 color "#ffd700" xalign 0.5

            vbox:
                spacing 4
                text t("Steuerung", "Controls") size 24 color "#ffd700"
                text t("Tippe oder klicke auf die rechte Seite des Bildschirms, um im Dialog voranzukommen. Auf der linken Seite kommst du zu früheren Zeilen zurück.", "Tap or click on the right side of the screen to move the dialogue forward. Tapping the left side takes you back to earlier lines.") size 21 color "#ffffff" xsize 580

            vbox:
                spacing 4
                text t("Punkte", "Points") size 24 color "#ffd700"
                text t("Während des Projekts sammelst du laufend Punkte in drei Bereichen: Qualität, Tempo und Funktionsumfang. Deine Entscheidungen in Gesprächen und Arbeitsphasen wirken sich direkt darauf aus.", "Throughout the project you continuously earn points in three areas: Quality, Speed, and Scope. Your choices in conversations and work phases directly affect these values.") size 21 color "#ffffff" xsize 580

            vbox:
                spacing 4
                text t("Das Ende", "The Ending") size 24 color "#ffd700"
                text t("Am Ende des Projekts entscheidet die Kombination deiner drei Werte, welches von mehreren möglichen Enden du bekommst -- von einem Bestresultat bis zu spürbaren Herausforderungen.", "At the end of the project, the combination of your three values decides which of several possible endings you get -- anywhere from a stellar result to some noticeable challenges.") size 21 color "#ffffff" xsize 580

            textbutton t("Zurück", "Back"):
                xalign 0.5
                action Hide("how_to_play")
                text_size 30
                text_color "#ffffff"
                text_hover_color "#ffd700"
                padding (20, 10)
                background "#00000099"
                hover_background "#ffd70055"


define SIDE_EVENT_POOL = [
    {"id": "boss_extra_task", "weight": 1, "label": "event_boss_extra_task"},
    {"id": "social_media_tiktok", "weight": 1, "label": "event_social_media_tiktok"},
    {"id": "colleague_needs_help", "weight": 1, "label": "event_colleague_needs_help"},
    {"id": "server_outage", "weight": 1, "label": "event_server_outage"},
    {"id": "dev_sick", "weight": 1, "label": "event_dev_sick"},
    {"id": "merge_conflict", "weight": 1, "label": "event_merge_conflict"},
    {"id": "dev_disagreement", "weight": 1, "label": "event_dev_disagreement"},
    {"id": "coffee_break_invite", "weight": 1, "label": "event_coffee_break_invite"},
]

init python:
    import random

    def pick_random_side_event():
        available = [e for e in SIDE_EVENT_POOL if e["id"] not in seen_random_event_ids]
        if not available:
            return None
        total_weight = sum(e["weight"] for e in available)
        roll = random.uniform(0, total_weight)
        upto = 0
        for e in available:
            upto += e["weight"]
            if roll <= upto:
                return e
        return available[-1]


default extras_accepted_count = 0

define EXTRA_EVENT_PENALTY = {"quality": -3, "speed": -4, "quantity": -2}

init python:
    def apply_extra_event_penalty():
        global extras_accepted_count
        extras_accepted_count += 1
        scale = 1 + (extras_accepted_count - 1) * 0.1
        adjust_stats(
            d_quality=int(EXTRA_EVENT_PENALTY["quality"] * scale),
            d_speed=int(EXTRA_EVENT_PENALTY["speed"] * scale),
            d_quantity=int(EXTRA_EVENT_PENALTY["quantity"] * scale),
        )

    def apply_decline_event_effect():
        pass


define FOCUS_CHOICE_DELTA = 10
define FOCUS_CHOICE_TRADEOFF = -3
define BALANCE_CHOICE_DELTA = 5

define PROJECT_WORK_CHOICES = [
    {"id": "focus_quality", "d_quality": FOCUS_CHOICE_DELTA, "d_speed": FOCUS_CHOICE_TRADEOFF, "d_quantity": FOCUS_CHOICE_TRADEOFF},
    {"id": "focus_speed", "d_quality": FOCUS_CHOICE_TRADEOFF, "d_speed": FOCUS_CHOICE_DELTA, "d_quantity": FOCUS_CHOICE_TRADEOFF},
    {"id": "focus_quantity", "d_quality": FOCUS_CHOICE_TRADEOFF, "d_speed": FOCUS_CHOICE_TRADEOFF, "d_quantity": FOCUS_CHOICE_DELTA},
    {"id": "focus_balance", "d_quality": BALANCE_CHOICE_DELTA, "d_speed": BALANCE_CHOICE_DELTA, "d_quantity": BALANCE_CHOICE_DELTA},
]

init python:
    def apply_project_work_choice(choice_id):
        for choice in PROJECT_WORK_CHOICES:
            if choice["id"] == choice_id:
                adjust_stats(
                    d_quality=choice["d_quality"],
                    d_speed=choice["d_speed"],
                    d_quantity=choice["d_quantity"],
                )
                return
        raise Exception("Unknown project work choice: %s" % choice_id)


define PROJECT_SLOT_INTROS = [
    ("Zeit, an BühlerTube weiterzuarbeiten. Worauf konzentriere ich mich?", "Time to keep working on BühlerTube. What should I focus on?"),
    ("Wieder ein paar Stunden Arbeitszeit -- wo setze ich an?", "A few more working hours -- where do I start?"),
    ("Die Entwicklung schaut mich erwartungsvoll an. Wie gehen wir vor?", "The developers look at me expectantly. How do we proceed?"),
    ("Zurück an die Arbeit. Worauf lege ich jetzt den Fokus?", "Back to work. What should I focus on now?"),
    ("Kurzer Boxenstopp im Kopf: Was bringt uns jetzt am meisten weiter?", "Quick mental pit stop: what helps us most right now?"),
    ("Der Bildschirm blinkt vorwurfsvoll. Also los -- wo packe ich an?", "The screen blinks accusingly. Alright -- where do I start?"),
    ("Nächster Block. Was steht heute ganz oben auf der Liste?", "Next block. What's at the top of the list today?"),
]

define PROJECT_CHOICE_TEXTS = {
    "focus_quality": [
        ("Auf Qualität achten", "Focus on quality"),
        ("Code nochmal gründlich prüfen", "Thoroughly review the code again"),
        ("Fehler ausbügeln, bevor es weitergeht", "Iron out bugs before moving on"),
        ("Tests schreiben, damit nichts kaputtgeht", "Write tests so nothing breaks"),
        ("Noch einmal drüberschauen, bevor wir weitermachen", "Take another pass before moving on"),
        ("Code-Review mit dem Team machen", "Do a code review with the team"),
        ("Randfälle nochmal genau durchdenken", "Think through edge cases carefully"),
    ],
    "focus_speed": [
        ("Schnell vorankommen", "Push forward quickly"),
        ("Tempo machen, keine Zeit verlieren", "Pick up the pace, no time to lose"),
        ("Einfach durchziehen", "Just push through"),
        ("Abkürzungen suchen, wo es geht", "Look for shortcuts wherever possible"),
        ("Aufs Wesentliche reduzieren und liefern", "Cut to the essentials and ship"),
        ("Kleinere Aufgaben zügig abarbeiten", "Work through smaller tasks quickly"),
        ("Den nächsten Meilenstein anpeilen", "Aim for the next milestone"),
    ],
    "focus_quantity": [
        ("Möglichst viele Features einbauen", "Add as many features as possible"),
        ("Noch eine Funktion mehr reinpacken", "Squeeze in one more feature"),
        ("Den Funktionsumfang erweitern", "Expand the feature set"),
        ("Ein neues Feature für BühlerTube skizzieren", "Sketch out a new feature for BühlerTube"),
        ("Die Wunschliste der Nutzenden abarbeiten", "Work through the users' wishlist"),
        ("Eine zusätzliche Idee umsetzen", "Implement an additional idea"),
    ],
    "focus_balance": [
        ("Alles im Gleichgewicht halten", "Keep everything balanced"),
        ("Ein bisschen von allem angehen", "Tackle a bit of everything"),
        ("Flexibel bleiben und je nachdem entscheiden", "Stay flexible and decide as it comes"),
        ("Zwischen den Baustellen hin und her wechseln", "Switch back and forth between the open tasks"),
        ("Überall etwas vorwärtsmachen", "Make a bit of progress everywhere"),
    ],
}

define PROJECT_REACTION_TEXTS = {
    "focus_quality": [
        ("Ich nehme mir Zeit, um es sauber zu machen.", "I take my time to do it cleanly."),
        ("Ich gehe jede Zeile nochmal durch.", "I go through every line again."),
        ("Ich schreibe noch ein paar Tests dazu.", "I add a few more tests."),
    ],
    "focus_speed": [
        ("Ich versuche, zügig voranzukommen.", "I try to move forward quickly."),
        ("Ich hämmere in die Tasten, so schnell es geht.", "I hammer at the keyboard as fast as I can."),
        ("Ich lasse Kleinigkeiten erstmal links liegen.", "I leave the small stuff for later."),
    ],
    "focus_quantity": [
        ("Ich baue noch ein paar zusätzliche Features ein.", "I add a few extra features."),
        ("Ich skizziere gleich noch eine weitere Funktion.", "I sketch out yet another function."),
        ("Ich setze die nächste Idee von der Liste um.", "I implement the next idea from the list."),
    ],
    "focus_balance": [
        ("Ich versuche, an allem ein bisschen zu arbeiten.", "I try to work on a bit of everything."),
        ("Ich springe zwischen den Baustellen hin und her.", "I hop back and forth between the open tasks."),
    ],
}

default used_project_choice_texts = {"focus_quality": [], "focus_speed": [], "focus_quantity": [], "focus_balance": []}

init python:
    def pick_unused_choice_text(choice_id):
        options = PROJECT_CHOICE_TEXTS[choice_id]
        used = used_project_choice_texts[choice_id]
        remaining = [opt for opt in options if opt not in used]
        if not remaining:
            used_project_choice_texts[choice_id] = []
            remaining = options
        chosen = random.choice(remaining)
        used_project_choice_texts[choice_id].append(chosen)
        return t(*chosen)

    def project_work_slot_texts():
        intro = t(*random.choice(PROJECT_SLOT_INTROS))
        order = ["focus_quality", "focus_speed", "focus_quantity", "focus_balance"]
        labels = {cid: pick_unused_choice_text(cid) for cid in order}
        reactions = {cid: t(*random.choice(PROJECT_REACTION_TEXTS[cid])) for cid in order}
        return intro, labels, reactions


init python:
    def montage_drift(num_days):
        for _ in range(num_days):
            dq = random.randint(-2, 3)
            ds = random.randint(-2, 3) if team_working else 0
            dn = random.randint(-1, 4)
            adjust_stats(d_quality=dq, d_speed=ds, d_quantity=dn, show_toast=False)


label start:

    scene vtsei
    show tom normal:
        yalign -0.2

    $ tom(t("Hallo! Ich bin Tom.", "Hello! I'm Tom."))
    $ tom(t("Wie heisst du?", "What's your name?"))

    $ player_name = renpy.input(t("Gib deinen Namen ein:", "Enter your name:"), length=20)
    $ player_name = player_name.strip()

    if player_name == "":
        $ player_name = t("Unbekannt", "Unknown")

    $ tom(t("Schön dich kennenzulernen, [player_name]!", "Nice to meet you, [player_name]!"))

    show tom show:
        xalign -4.0
        yalign -0.3
        xzoom -1

    $ tom(t("Hier befinden wir uns im Jarvis, in dem Raum, in dem die Informatik-Lernenden und wir EDBs arbeiten.", "This is the Jarvis, the room where the IT apprentices and we EDBs work."))
    $ p(t("EDB -- was macht man da eigentlich genau?", "EDB -- what does that role actually do?"))
    $ tom(t("EDB heisst 'Entwickler digitales Business', das ist eine ziemlich neue Lehre. Wir digitalisieren Geschäftsprozesse und begleiten Projekte -- also nicht selbst programmieren, sondern eher organisieren, planen und zwischen allen vermitteln.", "EDB stands for 'digital business developer', it's a pretty new apprenticeship. We digitalize business processes and support projects -- so not coding ourselves, more organizing, planning, and mediating between everyone involved."))
    $ tom(t("Konkret heisst das: mit der Kundschaft reden, den Überblick über Zeit, Qualität und Umfang behalten, und dem Team den Rücken freihalten, damit sie in Ruhe entwickeln können.", "In practice that means: talking with the client, keeping an eye on time, quality and scope, and keeping the team's back free so they can focus on developing."))

    show tom show:
        xalign 5.0
        xzoom 1.0

    show lisa normal:
        xalign -4.0

    $ tom(t("Das ist Lisa, sie ist bei uns für Social Media zuständig und gerade auch deine Hauptansprechsperson für ein neues Projekt.", "This is Lisa, she's in charge of social media here and is also your main contact for a new project right now."))
    $ lisa(t("Hallo [player_name], schön dich kennenzulernen! Wir drehen ab und zu Kurzvideos für unseren TikTok-Account -- vielleicht bist du auch mal dabei.", "Hello [player_name], nice to meet you! We shoot short videos for our TikTok account now and then -- maybe you'll join in sometime."))

    jump boss_intro


label boss_intro:
    hide tom
    hide lisa
    show nicola normal:
        pos_nicola

    $ boss(t("Guten Tag, ich bin Nicola, Abteilungsleiter der VTSEI.", "Good day, I'm Nicola, head of department of the VTSEI."))
    $ boss(t("Ich hab einen Auftrag für dich: BühlerTube, unsere neue interne Video-Plattform.", "I've got an assignment for you: BühlerTube, our new internal video platform."))
    $ p(t("Verstehe, als EDB leite ich also dieses Projekt und unterstütze die Lernenden bei der Umsetzung.", "Understood, so as an EDB I'll lead this project and support the apprentices with implementation."))
    $ boss(t("Genau, BühlerTube.", "Exactly, BühlerTube."))
    $ p(t("Also eine Art internes Video-Portal, oder? So was wie ein internes YouTube?", "So a kind of internal video portal, right? Something like an internal YouTube?"))
    $ boss(t("Nicht ganz -- hochladen können später nur die Vorgesetzten, zum Beispiel für Ankündigungen oder Schulungsvideos. Die Mitarbeitenden können die Videos schauen und kommentieren, aber nicht selbst hochladen.", "Not quite -- only supervisors will be able to upload later, for example for announcements or training videos. Employees can watch and comment on the videos, but can't upload themselves."))
    $ boss(t("Lisa ist deine Hauptansprechsperson dafür, sie sagt euch, was gebraucht wird. Ihr habt drei Wochen Zeit. Danach übergeben wir das Ganze an Lisa -- dann schauen wir, ob sie zufrieden ist.", "Lisa is your main contact for this, she'll tell you what's needed. You have three weeks for that. Afterwards we hand it over to Lisa -- then we'll see if she's happy with it."))
    $ p(t("Geht klar!", "Got it!"))
    hide nicola
    jump day_1


label draft_decision:
    $ boss(t("Bevor es losgeht: Soll euer Team einen Entwurf erstellen? Das ist eine grobe Skizze oder ein Prototyp, bevor ihr richtig mit der Entwicklung beginnt.", "Before we start: should your team create a draft? That's a rough sketch or prototype before you really start development."))
    $ boss(t("Das dauert länger, aber die Qualität am Ende ist besser.", "It takes longer, but the quality at the end will be better."))

    $ draft_option_yes = t("Team macht einen Entwurf (dauert länger, aber bessere Qualität)", "Team makes a draft (takes longer, but better quality)")
    $ draft_option_no = t("Kein Entwurf (spart Zeit)", "No draft (saves time)")

    menu:
        "[draft_option_yes]":
            $ draft_chosen = True
            $ deadline_day += DRAFT_TIME_COST_DAYS
            $ adjust_stats(d_quality=DRAFT_QUALITY_BONUS)
            $ boss(t("Gute Wahl. Das gibt euch mehr Sicherheit.", "Good choice. That gives you more safety margin."))

        "[draft_option_no]":
            $ draft_chosen = False
            $ boss(t("Okay, dann direkt rein in die Umsetzung.", "Okay, straight into implementation then."))

    jump expression next_label


label day_1:
    $ current_day = 1
    $ current_time = 9
    $ team_working = False

    $ new_day_scene()

    $ p(t("Mein erster Tag für EDB bei BühlerTube beginnt.", "My first day as an EDB on BühlerTube begins."))
    show tom normal:
        yalign -0.2
    $ tom(t("Komm mit, ich stell dich kurz deinen zwei Lernenden vor.", "Come on, I'll introduce you to your two apprentices."))

    show brian normal:
        pos_brian_paired
    show ember normal:
        pos_ember_paired

    $ tom(t("Das sind Brian und Ember. Die beiden entwickeln mit dir zusammen BühlerTube -- ihr drei seid ab jetzt ein Team.", "This is Brian and Ember. The two of them will develop BühlerTube together with you -- the three of you are a team from now on."))
    $ dev1(t("Wir sind die Entwicklung, BühlerTube wird von uns programmiert.", "We're the developers, BühlerTube will be programmed by us."))
    $ dev2(t("Freut uns, [player_name].", "Nice to meet you, [player_name]."))
    $ p(t("Ich freue mich auf die Zusammenarbeit.", "Looking forward to working together."))
    hide tom
    hide brian
    hide ember

    jump day_2


label day_2:
    $ current_day = 2
    $ current_time = 9
    $ team_working = True

    $ new_day_scene()

    jump planning_start


label planning_start:
    show nicola normal:
        pos_nicola
    $ boss(t("Guten Morgen! Heute startet die Planungsphase für BühlerTube.", "Good morning! Today the planning phase for BühlerTube starts."))
    $ p(t("Verstanden, wir legen los.", "Understood, let's get started."))
    hide nicola

    scene lernlandschaft at time_tint()
    show brian normal:
        pos_brian_paired
    show ember normal:
        pos_ember_paired

    jump planning_team_focus


label planning_team_focus:
    $ p(t("Wir müssen uns jetzt überlegen, wie wir in den 3 Wochen BühlerTube rechtzeitig abgeben. Fokussieren wir uns eher auf Qualität oder auf Quantität, was sagt ihr?", "We need to work out now how we'll get BühlerTube in on time within the 3 weeks. Should we focus more on quality or on quantity, what do you think?"))
    $ dev1(t("Ich sage, wir achten mehr auf Qualität, dann läuft die Plattform zuverlässig und fehlerfrei.", "I say we focus on quality, so the platform runs reliably and bug-free."))
    $ dev2(t("Ich sage, wir achten mehr auf Quantität, damit haben Mitarbeitende mehr Funktionen.", "I say we focus on quantity, so employees get more features."))
    $ p(t("Achten wir lieber auf...", "Let's rather focus on..."))

    $ focus_quality_opt = t("Qualität -- BühlerTube wird übersichtlich und stabil, hat aber eher begrenzte Funktionalität.", "Quality -- BühlerTube will be clean and stable, but with rather limited functionality.")
    $ focus_quantity_opt = t("Quantität -- BühlerTube bekommt mehr Funktionen, wird aber allenfalls unübersichtlicher.", "Quantity -- BühlerTube gets more features, but may become less clear.")
    $ focus_balance_opt = t("Bei Nicola nachfragen, ob mehr Zeit möglich ist, damit wir beides angehen können.", "Ask Nicola whether more time is possible, so we can tackle both.")

    menu:
        "[focus_quality_opt]":
            $ planning_focus = "quality"
            $ apply_project_work_choice("focus_quality")
            $ dev1(t("Ja, das klingt gut, wir schauen, dass BühlerTube qualitativ gut wird.", "Yes, that sounds good, we'll make sure BühlerTube is high quality."))

        "[focus_quantity_opt]":
            $ planning_focus = "quantity"
            $ apply_project_work_choice("focus_quantity")
            $ dev2(t("Wir achten auf Quantität, perfekt.", "We'll focus on quantity, perfect."))

        "[focus_balance_opt]":
            $ planning_focus = "balance"
            $ apply_project_work_choice("focus_balance")
            show nicola normal:
                pos_nicola
            $ p(t("Nicola, wäre es möglich, etwas mehr Zeit zu bekommen, damit wir Qualität und Quantität gleichermassen angehen können?", "Nicola, would it be possible to get a bit more time, so we can tackle quality and quantity equally?"))
            $ boss(t("Mehr Zeit kann ich euch nicht geben, die Deadline steht fest. Wenn ihr beides wollt, müsst ihr das in der bestehenden Zeit schaffen -- das wird knapp.", "I can't give you more time, the deadline is fixed. If you want both, you'll have to manage it in the existing time -- that'll be tight."))
            $ adjust_stats(d_speed=-3)
            $ dev1(t("Ok, dann versuchen wir eben, ein bisschen von allem zu machen.", "Ok, then we'll try to do a bit of everything."))
            hide nicola

    jump planning_draft_choice


label planning_draft_choice:
    show nicola normal:
        pos_nicola
    $ next_label = "planning_tool_choice"
    jump draft_decision


label planning_tool_choice:
    hide nicola
    $ p(t("Nun müssen wir auswählen, welche Programmiersprache wir verwenden sollten. Entweder eine neue oder eine bekannte, was meint ihr?", "Now we need to pick which programming language to use. Either a new one or a familiar one, what do you think?"))
    $ dev1(t("Die neue ist besser geeignet, aber wir haben sie noch nie verwendet und müssten sie neu lernen. Mit der bekannten sind wir relativ langsam, kennen uns aber gut damit aus.", "The new one is better suited, but we've never used it and would have to learn it from scratch. With the familiar one we're relatively slow, but we know it well."))
    $ p(t("Wie lange bräuchtet ihr, um die neue Sprache zu lernen?", "How long would you need to learn the new language?"))
    $ dev2(t("Etwa 1 bis 2 Wochen.", "About 1 to 2 weeks."))
    $ p(t("Wählen wir...", "Let's choose..."))

    $ tool_new_opt = t("Die neue Programmiersprache ist die bessere Entscheidung -- obwohl sie sie noch nie verwendet haben, holen wir das am Schluss wieder auf.", "The new language is the better choice -- even though they've never used it, we'll catch up by the end.")
    $ tool_familiar_opt = t("Lieber die bekannte Programmiersprache -- eine neue zu lernen dauert zu lange.", "Better the familiar language -- learning a new one takes too long.")

    menu:
        "[tool_new_opt]":
            $ dev_tool = "angular"
            $ dev1(t("OK, dann werden wir mal die neue Programmiersprache für BühlerTube verwenden.", "OK, then we'll use the new language for BühlerTube."))

        "[tool_familiar_opt]":
            $ dev_tool = "powerapps"
            $ dev2(t("Verstanden, die bekannte Programmiersprache klingt gut.", "Understood, the familiar language sounds good."))

    $ dev1(t("Damit wäre die Planung soweit fertig. Sollen wir sie Nicola zeigen, bevor wir loslegen?", "That would wrap up the planning. Should we show it to Nicola before we get going?"))
    $ p(t("Ja, gute Idee -- oder sollen wir lieber noch alles einmal in Ruhe durchgehen, bevor wir zu ihr gehen?", "Yes, good idea -- or should we go through everything calmly once more before we go to her?"))

    $ review_more_opt = t("Ich finde, wir sollten nochmals alles gut anschauen, bevor wir zu Nicola gehen.", "I think we should take another good look at everything before we go to Nicola.")
    $ review_rush_opt = t("Nein, gehen wir gleich zu Nicola -- ändert das etwas, wenn wir warten?", "No, let's go straight to Nicola -- would waiting change anything?")

    menu:
        "[review_more_opt]":
            $ planning_reviewed = True
            $ dev1(t("Gut, dann nehmen wir uns noch etwas Zeit, damit später nichts Unklares auftaucht.", "Good, then we'll take some more time so nothing is unclear later."))

        "[review_rush_opt]":
            $ planning_reviewed = False
            $ dev2(t("Passt, dann zeigen wir Nicola direkt, was wir geplant haben. Wenn ihr noch etwas unklar ist, klärt sie das wohl gleich mit uns ab.", "Fine, then we'll show Nicola directly what we've planned. If something's still unclear, she'll probably sort it out with us right away."))

    jump planning_boss_review


label planning_boss_review:
    show nicola normal:
        pos_nicola
    $ p(t("Wir wären mit der Planung fertig, Nicola, hast du Zeit?", "We'd be done with planning, Nicola, do you have a moment?"))
    $ boss(t("Ja, sicher.", "Yes, sure."))
    $ tool_name = tool_display_name(dev_tool)

    if planning_focus == "quality":
        $ p(t("Wir schauen auf die Qualität, verwenden [tool_name], und was wir noch nicht genau wissen, finden wir in der Entwicklung noch heraus.", "We're focusing on quality, using [tool_name], and whatever we don't know yet, we'll figure out during development."))
        $ boss(t("Also, dass ihr auf die Qualität achtet, finde ich gut.", "So, that you're focusing on quality, I like that."))
    elif planning_focus == "quantity":
        $ p(t("Wir schauen auf die Quantität, verwenden [tool_name], und was wir noch nicht genau wissen, finden wir in der Entwicklung noch heraus.", "We're focusing on quantity, using [tool_name], and whatever we don't know yet, we'll figure out during development."))
        $ boss(t("Also, dass ihr auf möglichst viele Funktionen setzt, ist mutig -- das müsst ihr dann auch sauber umsetzen.", "So, betting on as many features as possible is bold -- you'll need to implement that cleanly too."))
    else:
        $ p(t("Wir versuchen, Qualität und Quantität im Gleichgewicht zu halten, verwenden [tool_name], und den Rest klären wir während der Entwicklung.", "We're trying to keep quality and quantity balanced, using [tool_name], and we'll sort out the rest during development."))
        $ boss(t("Ein Mittelweg -- das kann funktionieren, wenn ihr es konsequent durchzieht.", "A middle path -- that can work, if you follow through on it consistently."))

    if draft_chosen:
        $ boss(t("Gut, dass ihr euch für einen Entwurf entschieden habt -- das gibt euch mehr Sicherheit, kostet euch aber auch Zeit.", "Good that you decided on a draft -- that gives you more safety margin, but it costs you time too."))

    if dev_tool == "angular":
        $ boss(t("Mit der neuen Programmiersprache hingegen braucht ihr viel zu viel Zeit, um sie zu lernen -- das geht nicht.", "The new language, on the other hand, will take you way too long to learn -- that won't work."))

    if not planning_reviewed:
        $ boss(t("Und ihr fangt sicher nicht schon an mit der Entwicklung, wenn ihr noch nicht genau wisst, wie ihr alles macht.", "And you're certainly not starting development yet if you don't even know exactly how you're going to do everything."))

    if dev_tool == "angular" or not planning_reviewed:
        $ p(t("Verstehe, wir werden uns darum kümmern.", "Understood, we'll take care of that."))

        if dev_tool == "angular":
            $ dev_tool = "powerapps"
            $ adjust_stats(d_speed=-4)
            $ dev2(t("Gut, dann nehmen wir doch die bekannte Programmiersprache -- so verlieren wir keine Zeit mehr mit Lernen.", "Fine, we'll go with the familiar language after all -- that way we don't lose more time learning."))

        if not planning_reviewed:
            $ planning_reviewed = True
            $ adjust_stats(d_quality=2, d_speed=-2)
            $ dev1(t("Wir gehen die Planung nochmal in Ruhe durch, bevor wir loslegen.", "We'll go through the plan calmly once more before we start."))

        $ p(t("Perfekt, wir sind jetzt bereit für die Entwicklung.", "Perfect, we're now ready for development."))
    else:
        $ boss(t("Gut, dann könnt ihr direkt loslegen.", "Good, then you can get started right away."))

    hide nicola
    hide brian
    hide ember
    scene vtsei at time_tint()

    $ current_time = 13
    $ next_label = "day2_after_afternoon_slot"
    jump slot_event_or_project


label day2_after_afternoon_slot:
    $ current_time = 15
    jump planning_finished


label planning_finished:
    show nicola normal:
        pos_nicola
    $ boss(t("Gut, die Planung für heute ist abgeschlossen.", "Good, planning for today is done."))
    $ p(t("Dann sehen wir morgen weiter.", "We'll continue tomorrow then."))
    hide nicola
    jump end_of_day


label slot_event_or_project:
    $ roll = random.random()

    if roll < EVENT_CHANCE and random_events_triggered < MAX_RANDOM_EVENTS:
        $ chosen_event = pick_random_side_event()
        if chosen_event is not None:
            $ seen_random_event_ids.append(chosen_event["id"])
            $ random_events_triggered += 1
            jump expression chosen_event["label"]

    if team_working:
        jump project_work_slot
    else:
        jump idle_slot


label idle_slot:
    $ p(t("Gerade ist nichts zu tun, das Team arbeitet noch nicht an BühlerTube.", "There's nothing to do right now, the team isn't working on BühlerTube yet."))
    jump expression next_label


label project_work_slot:
    $ _pw_intro, _pw_labels, _pw_reactions = project_work_slot_texts()
    $ p(_pw_intro)

    menu:
        "[_pw_labels['focus_quality']]":
            $ apply_project_work_choice("focus_quality")
            $ p(_pw_reactions["focus_quality"])

        "[_pw_labels['focus_speed']]":
            $ apply_project_work_choice("focus_speed")
            $ p(_pw_reactions["focus_speed"])

        "[_pw_labels['focus_quantity']]":
            $ apply_project_work_choice("focus_quantity")
            $ p(_pw_reactions["focus_quantity"])

        "[_pw_labels['focus_balance']]":
            $ apply_project_work_choice("focus_balance")
            $ p(_pw_reactions["focus_balance"])

    $ maybe_show_high_stat_warning()

    jump expression next_label


label event_boss_extra_task:
    show nicola normal:
        pos_nicola
    $ boss(t("Hast du kurz Zeit, [player_name]? Ich bräuchte Hilfe bei etwas anderem.", "Do you have a moment, [player_name]? I could use help with something else."))

    $ choice_help = t("Helfen", "Help out")
    $ choice_decline = t("Ablehnen", "Decline")

    menu:
        "[choice_help]":
            $ apply_extra_event_penalty()
            $ p(t("Klar, ich helfe kurz aus.", "Sure, I'll help out for a bit."))
        "[choice_decline]":
            $ apply_decline_event_effect()
            $ p(t("Tut mir leid, ich muss gerade an BühlerTube bleiben.", "Sorry, I need to stay focused on BühlerTube right now."))

    hide nicola
    jump expression next_label


label event_social_media_tiktok:
    scene lernlandschaft at time_tint()
    show lisa filming

    $ lisa(t("Hey [player_name], hast du kurz Zeit? Wir drehen ein TikTok und könnten noch ein Gesicht gebrauchen.", "Hey [player_name], got a minute? We're filming a TikTok and could use another face."))
    $ p(t("Wie lange dauert das denn?", "How long would that take?"))
    $ lisa(t("Rechne mit etwa einem Tag.", "Count on about a day."))

    $ choice_join = t("Ja, ich mache gerne mit.", "Yes, I'd like to join in.")
    $ choice_decline = t("Ich kann gerade nicht.", "I can't right now.")

    menu:
        "[choice_join]":
            $ apply_extra_event_penalty()
            show lisa thumbsup
            $ lisa(t("Perfekt, wir freuen uns.", "Perfect, we're looking forward to it."))
        "[choice_decline]":
            $ apply_decline_event_effect()
            $ lisa(t("Verstehe, dann müssen wir es verschieben.", "I understand, then we'll have to postpone it."))

    scene vtsei at time_tint()
    hide lisa
    jump expression next_label


label event_colleague_needs_help:
    show brian normal:
        pos_brian_solo
    $ dev1(t("Kannst du mir kurz bei etwas helfen, [player_name]? Ich komme gerade nicht weiter.", "Can you help me with something, [player_name]? I'm stuck right now."))

    $ choice_help = t("Helfen", "Help out")
    $ choice_decline = t("Ablehnen", "Decline")

    menu:
        "[choice_help]":
            $ apply_extra_event_penalty()
            $ p(t("Klar, zeig mal her.", "Sure, show me."))
        "[choice_decline]":
            $ apply_decline_event_effect()
            $ p(t("Sorry, ich muss gerade weiterarbeiten.", "Sorry, I need to keep working right now."))

    hide brian
    jump expression next_label


label event_server_outage:
    $ p(t("Auf einmal ist der Server down. Das kostet Zeit.", "Suddenly the server goes down. This costs time."))
    $ adjust_stats(d_speed=-5)
    $ p(t("Nach ein paar Minuten läuft alles wieder.", "After a few minutes, everything is back up."))
    jump expression next_label


label event_dev_sick:
    show brian stressed:
        pos_brian_solo
    $ dev1(t("Mir geht's heute gar nicht gut, ich glaube ich muss zuhause bleiben.", "I'm not feeling well today, I think I need to stay home."))
    hide brian
    show ember normal:
        pos_ember_solo
    $ dev2(t("Oh nein, und wir haben doch noch so viel zu tun...", "Oh no, and we still have so much to do..."))

    $ choice_wait = t("Abwarten, bis er wieder da ist.", "Wait until he's back.")
    $ choice_split = t("Ember seinen Teil übernehmen lassen.", "Have Ember take over his part.")

    menu:
        "[choice_wait]":
            $ adjust_stats(d_speed=-6)
            $ dev2(t("Verstehe, dann warten wir -- den Rest der Zeit müssen wir aufholen.", "I see, we'll wait then -- we'll have to catch up the rest of the time."))
        "[choice_split]":
            $ adjust_stats(d_speed=-2, d_quality=-3)
            $ dev2(t("Verstanden, ich brauche einfach etwas länger, aber es geht.", "Understood, I'll just need a bit longer, but it'll work."))

    hide ember
    jump expression next_label


label event_merge_conflict:
    show brian normal:
        pos_brian_paired
    show ember normal:
        pos_ember_paired
    $ dev1(t("Hä, wieso funktioniert das jetzt nicht mehr?", "Huh, why doesn't this work anymore?"))
    $ dev2(t("Warte, ich glaube wir haben beide am gleichen Teil gearbeitet...", "Wait, I think we both worked on the same part..."))
    $ p(t("Wie machen wir es -- schauen wir es gemeinsam an, oder löschen wir den Teil und machen ihn neu?", "How do we handle this -- do we look at it together, or delete the part and redo it?"))

    $ choice_review = t("Gemeinsam anschauen.", "Look at it together.")
    $ choice_delete = t("Löschen und neu machen.", "Delete it and redo it.")

    menu:
        "[choice_review]":
            $ adjust_stats(d_speed=-3)
            $ dev1(t("Das hat etwas gedauert, aber jetzt passt wieder alles zusammen. Nichts ist verloren gegangen.", "That took a while, but now everything fits together again. Nothing was lost."))
        "[choice_delete]":
            $ adjust_stats(d_speed=-5, d_quantity=-2)
            $ dev2(t("Das ging schnell, aber wir müssen es jetzt nochmal neu machen, das wird etwas dauern.", "That was quick, but now we have to redo it from scratch, that'll take a while."))

    hide brian
    hide ember
    jump expression next_label


label event_dev_disagreement:
    show brian normal:
        pos_brian_paired
    show ember normal:
        pos_ember_paired
    $ dev1(t("Es muss so gemacht werden!", "It has to be done this way!"))
    $ dev2(t("Nein, so muss man es coden!", "No, this is how you code it!"))
    $ p(t("Was ist los?", "What's going on?"))
    $ dev1(t("Wir sind verschiedener Meinung, wie es gemacht werden soll.", "We disagree on how this should be done."))

    $ choice_together = t("Zusammen eine gemeinsame Lösung finden.", "Work out a solution together.")
    $ choice_decide = t("Selbst entscheiden, wem du eher zustimmst.", "Decide yourself who you tend to agree with.")

    menu:
        "[choice_together]":
            $ adjust_stats(d_quality=2, d_speed=-2)
            $ dev1(t("Gut, das war fair. Wir sind wieder zufrieden und motiviert.", "Good, that was fair. We're happy and motivated again."))
        "[choice_decide]":
            $ adjust_stats(d_speed=2, d_quantity=-3)
            $ dev2(t("Na gut, wenn du meinst. Ich mach dann nur noch das Nötigste.", "Fine, if you say so. I'll just do the bare minimum then."))

    hide brian
    hide ember
    jump expression next_label


label event_coffee_break_invite:
    $ coffee_break_seen = True

    scene lounge at time_tint()
    show lisa normal:
        xalign 0
    show mei ling normal:
        xalign 5.0
    show baljeet normal:
        xalign -4.0

    $ lisa(t("Kaffeepause? Komm doch kurz mit in die Lounge.", "Coffee break? Come join us in the lounge for a bit."))
    $ meiling(t("Genau, wir machen gerade eh Pause.", "Exactly, we're taking a break right now anyway."))
    $ baljeet(t("Setz dich zu uns, ein bisschen Kaffee hat noch niemandem geschadet.", "Come sit with us, a little coffee never hurt anyone."))

    $ choice_join = t("Mitkommen", "Join them")
    $ choice_decline = t("Später vielleicht", "Maybe later")

    menu:
        "[choice_join]":
            $ adjust_stats(d_quality=2, d_speed=-3)
            show baljeet thumbsup
            $ p(t("Eine kurze Pause tut gut, mit klarem Kopf sieht man vieles wieder deutlicher.", "A short break feels good, a clear head makes things easier to see."))

            hide lisa
            show baljeet normal
            show nicola coffee:
                xalign 0.5
                yalign 0.1
            $ boss(t("Ah, auch hier -- guter Kaffee heute, oder?", "Ah, you're here too -- good coffee today, isn't it?"))
            hide nicola

        "[choice_decline]":
            $ adjust_stats(d_speed=2, d_quality=-2)
            $ p(t("Ich bleibe lieber dran.", "I'd rather keep at it."))

    hide mei ling
    hide baljeet
    scene vtsei at time_tint()
    jump expression next_label


label day_3:
    $ current_day = 3
    $ current_time = 9
    $ team_working = True

    $ new_day_scene()

    $ p(t("Tag drei. Heute geht die eigentliche Umsetzung richtig los.", "Day three. Today real implementation actually begins."))
    show tom serious
    $ tom(t("Wie fühlst du dich? Bereit für den ersten vollen Arbeitstag?", "How are you feeling? Ready for your first full working day?"))

    $ feeling_good_opt = t("Bereit, mal schauen, wie der Tag läuft.", "Ready, let's see how the day goes.")
    $ feeling_nervous_opt = t("Etwas nervös, aber ich pack das schon.", "A bit nervous, but I'll manage.")

    menu:
        "[feeling_good_opt]":
            $ p(t("Bereit, mal schauen, wie der Tag läuft.", "Ready, let's see how the day goes."))
            $ tom(t("Diese Einstellung gefällt mir.", "I like that attitude."))
        "[feeling_nervous_opt]":
            $ p(t("Etwas nervös, aber ich pack das schon.", "A bit nervous, but I'll manage."))
            $ tom(t("Das ist völlig normal, das gibt sich schnell.", "That's completely normal, it'll pass quickly."))
    hide tom

    $ current_time = 9
    $ next_label = "day3_after_morning_slot"
    jump slot_event_or_project

label day3_after_morning_slot:
    $ current_time = 12
    show nicola normal:
        pos_nicola
    $ boss(t("Mittagspause! Wie läuft es bei euch?", "Lunch break! How's it going for you?"))

    $ choice_report_good = t("Ganz gut, wir kommen voran.", "Pretty well, we're making progress.")
    $ choice_report_meh = t("Es könnte besser laufen.", "It could be going better.")

    menu:
        "[choice_report_good]":
            $ boss(t("Schön zu hören, weiter so.", "Good to hear, keep it up."))
        "[choice_report_meh]":
            $ boss(t("Sag Bescheid, falls ihr Unterstützung braucht.", "Let me know if you need support."))
    hide nicola

    $ current_time = 13
    $ next_label = "day3_after_afternoon_slot"
    jump slot_event_or_project

label day3_after_afternoon_slot:
    $ current_time = 18
    $ p(t("Der erste volle Arbeitstag ist geschafft. Anstrengend, aber okay.", "The first full workday is done. Tiring, but okay."))
    jump end_of_day


label day_4:
    $ current_day = 4
    $ current_time = 9
    $ team_working = True

    $ new_day_scene()

    show lisa normal
    $ lisa(t("Guten Morgen! Heute ist bei uns im Büro ordentlich was los, glaub mir.", "Good morning! There's a lot going on in the office today, trust me."))
    $ p(t("Klingt vielversprechend...", "Sounds promising..."))
    hide lisa

    $ current_time = 9
    $ next_label = "day4_slot_2"
    jump slot_event_or_project

label day4_slot_2:
    $ current_time = 12
    $ next_label = "day4_slot_3"
    jump slot_event_or_project

label day4_slot_3:
    $ current_time = 14
    $ next_label = "day4_after_last_slot"
    jump slot_event_or_project

label day4_after_last_slot:
    $ current_time = 18
    $ p(t("Was für ein turbulenter Tag. Morgen wird hoffentlich ruhiger.", "What a turbulent day. Hopefully tomorrow will be calmer."))
    jump end_of_day


label montage_day5:
    $ current_time = 9
    $ new_day_scene()

    $ p(t("Nach dem turbulenten Vortag beginnt Tag fünf ruhiger.", "After the turbulent day before, day five starts off calmer."))
    show tom normal
    $ tom(t("Wir arbeiten, wir stolpern über die üblichen kleinen Probleme, wir machen weiter.", "We work, we stumble over the usual small problems, we carry on."))
    hide tom

    if draft_chosen:
        $ p(t("Der Entwurf zahlt sich langsam aus -- wir wissen, worauf wir hinarbeiten.", "The draft is starting to pay off -- we know what we're working towards."))
    else:
        $ p(t("Ohne Entwurf improvisieren wir gelegentlich, aber es funktioniert bisher.", "Without a draft we improvise here and there, but it's working so far."))

    $ montage_drift(1)
    $ current_time = 18

    jump end_of_day


label day_6:
    $ current_day = 6
    $ current_time = 10
    $ team_working = True

    $ new_day_scene()

    show lisa normal
    $ lisa(t("Ich hab mir das nochmal überlegt: Ich möchte gerne noch ein Moderationssystem in BühlerTube.", "I've been thinking about this: I'd like to add a moderation system to BühlerTube."))
    $ lisa(t("Sobald Leute kommentieren können, wird früher oder später auch mal was Unpassendes dabei sein. Damit könnten wir gemeldete Kommentare prüfen und bei Bedarf löschen.", "Once people can comment, sooner or later something inappropriate will show up. This way we could review flagged comments and delete them if needed."))
    $ lisa(t("Das gibt euch mehr Umfang, kostet euch aber Zeit, die ihr eigentlich nicht habt.", "That gives you more scope, but it costs you time you don't really have."))

    show brian normal:
        pos_brian_paired
    show ember normal:
        pos_ember_paired
    $ dev1(t("Ein Moderationssystem klingt sinnvoll für die Präsentation, aber wir liegen jetzt schon eng im Zeitplan.", "A moderation system sounds useful for the presentation, but we're already tight on schedule."))
    $ dev2(t("Ich würd sagen, das ist deine Entscheidung -- du kennst den Gesamtstand am besten.", "I'd say that's your call -- you know the overall status best."))

    $ scope_accept_opt = t("Moderationssystem annehmen -- mehr Umfang, aber weniger Zeit für den Rest.", "Accept the moderation system -- more scope, but less time for everything else.")
    $ scope_decline_opt = t("Ablehnen -- lieber beim ursprünglichen Plan bleiben.", "Decline -- better to stick with the original plan.")

    menu:
        "[scope_accept_opt]":
            $ scope_request_accepted = True
            $ adjust_stats(d_quantity=8, d_speed=-5)
            $ p(t("Gut, wir nehmen das Moderationssystem mit rein.", "Alright, we'll add the moderation system in."))
            $ lisa(t("Danke, das wird gut ankommen -- und macht die Plattform sicherer.", "Thanks, that'll go over well -- and it makes the platform safer."))
        "[scope_decline_opt]":
            $ scope_request_accepted = False
            $ adjust_stats(d_speed=2)
            $ p(t("Ich denke, wir bleiben lieber beim ursprünglichen Umfang.", "I think we'd rather stick with the original scope."))
            $ lisa(t("Verstehe ich. Sicherheit geht vor.", "I understand. Better safe than sorry."))

    hide lisa
    hide brian
    hide ember

    $ current_time = 18
    jump end_of_day


label montage_day7:
    $ current_time = 9
    $ new_day_scene()

    if scope_request_accepted:
        $ p(t("Das Moderationssystem beschäftigt uns noch, aber wir kommen voran.", "The moderation system keeps us busy, but we're making progress."))
    else:
        $ p(t("Ohne das Moderationssystem können wir uns ganz auf den ursprünglichen Plan konzentrieren.", "Without the moderation system we can focus entirely on the original plan."))

    $ montage_drift(1)
    $ current_time = 18

    $ p(t("Fast eine Woche ist jetzt vorbei.", "Almost a week has passed now."))
    jump end_of_day


label day_8:
    $ current_day = 8
    $ current_time = 9
    $ team_working = True

    $ new_day_scene()

    show nicola normal:
        pos_nicola
    $ boss(t("Wir sind jetzt gut eine Woche unterwegs. Zeit für ein Zwischenfazit.", "We're now a good week into this. Time for a check-in."))
    $ boss(t("Wie steht es um Qualität, Tempo und Umfang von BühlerTube?", "How are quality, speed, and scope of BühlerTube looking?"))

    $ choice_honest = t("Ehrlich berichten, wo wir stehen.", "Report honestly on where we stand.")
    $ choice_optimistic = t("Optimistisch berichten, um Druck rauszunehmen.", "Report optimistically to take the pressure off.")

    menu:
        "[choice_honest]":
            $ p(t("Ich erzähle ihr ehrlich, wo wir Probleme haben und wo es gut läuft.", "I honestly tell her where we have problems and where things are going well."))
            $ boss(t("Das schätze ich. Ehrlichkeit hilft mir, euch richtig zu unterstützen.", "I appreciate that. Honesty helps me support you properly."))
            $ adjust_stats(d_quality=2)
        "[choice_optimistic]":
            $ p(t("Ich zeichne ein positiveres Bild, als es vielleicht wirklich ist.", "I paint a rosier picture than things maybe really are."))
            $ boss(t("Gut zu hören. Ich verlasse mich darauf, dass das stimmt.", "Good to hear. I'm counting on that being accurate."))
            $ adjust_stats(d_speed=2, d_quantity=-2)
    hide nicola

    $ current_time = 10
    $ next_label = "day8_after_morning_slot"
    jump slot_event_or_project

label day8_after_morning_slot:
    $ current_time = 13
    show ember serious:
        pos_ember_solo
    $ dev2(t("Ehrlich gesagt bin ich gerade ziemlich im Stress mit dem Ganzen.", "Honestly, I'm pretty stressed with everything right now."))

    $ ember_support_opt = t("Ember beruhigen und kurz zuhören.", "Reassure Ember and listen for a moment.")
    $ ember_move_on_opt = t("Kurz nicken und weitermachen.", "Nod briefly and move on.")

    menu:
        "[ember_support_opt]":
            $ ember_supported = True
            $ adjust_stats(d_quality=1)
            $ p(t("Hey, das schaffen wir zusammen. Sag einfach, wenn's zu viel wird.", "Hey, we'll get through this together. Just say something if it gets to be too much."))
            $ dev2(t("Danke, das hilft wirklich.", "Thanks, that actually helps."))
        "[ember_move_on_opt]":
            $ p(t("Kopf hoch, wir kriegen das hin.", "Chin up, we'll get it done."))
    hide ember

    $ next_label = "day8_after_afternoon_slot"
    jump slot_event_or_project

label day8_after_afternoon_slot:
    $ current_time = 18
    $ p(t("Ein Tag mit ehrlichem Blick auf den Fortschritt -- gut so.", "A day with an honest look at progress -- good."))
    jump end_of_day


label montage_9_to_11:
    $ current_time = 9
    $ new_day_scene()

    $ p(t("Die zweite Woche zieht sich hin, aber die Routine hilft.", "The second week drags on, but the routine helps."))
    show lisa normal
    $ lisa(t("Ihr seid echt fleissig -- ich hab kaum von euch gehört, weil ihr so beschäftigt seid.", "You've been really diligent -- I've barely heard from you because you're so busy."))
    hide lisa

    $ montage_drift(3)
    $ current_day += 2
    $ current_time = 18

    if not coffee_break_seen and random_events_triggered < MAX_RANDOM_EVENTS:
        jump event_coffee_break_guaranteed

    $ p(t("Fast zwei Wochen sind jetzt vorbei. Die Deadline rückt näher.", "Almost two weeks are over now. The deadline is getting closer."))
    jump end_of_day


label event_coffee_break_guaranteed:
    $ seen_random_event_ids.append("coffee_break_invite")
    $ random_events_triggered += 1
    $ next_label = "montage_9_to_11_after_coffee"
    jump event_coffee_break_invite

label montage_9_to_11_after_coffee:
    $ p(t("Fast zwei Wochen sind jetzt vorbei. Die Deadline rückt näher.", "Almost two weeks are over now. The deadline is getting closer."))
    jump end_of_day


label day_12:
    $ current_day = 12
    $ current_time = 9
    $ team_working = True

    $ new_day_scene()

    show nicola normal:
        pos_nicola
    $ boss(t("Die Deadline rückt jetzt spürbar näher. Ab jetzt zählt jeder Tag.", "The deadline is getting noticeably closer now. Every day counts from here."))
    $ p(t("Verstanden. Ich gebe nochmal richtig Gas.", "Understood. I'll really push now."))
    hide nicola

    show brian stressed:
        pos_brian_solo
    $ dev1(t("Puh, es wird gerade ziemlich eng, aber wir schaffen das schon.", "Ugh, it's getting pretty tight, but we'll manage."))
    hide brian

    show ember normal:
        pos_ember_solo
    if ember_supported:
        $ dev2(t("Danke nochmal, dass du letzte Woche für mich da warst -- das gibt mir gerade echt Kraft.", "Thanks again for being there for me last week -- it's really giving me strength right now."))
    else:
        $ dev2(t("Wird schon irgendwie klappen, so wie immer.", "It'll work out somehow, like it always does."))
    hide ember

    $ current_time = 9
    $ next_label = "day12_slot_2"
    jump slot_event_or_project

label day12_slot_2:
    $ current_time = 10
    show lisa normal
    $ lisa(t("Wir brauchen dringend jemanden für ein TikTok, ziemlich kurzfristig.", "We urgently need someone for a TikTok, pretty short notice."))
    $ p(t("Gerade jetzt? Wir stecken mitten in der Umsetzung von BühlerTube.", "Right now? We're right in the middle of implementing BühlerTube."))

    $ choice_help_lisa = t("Trotzdem helfen -- Lisa im Stich lassen fühlt sich falsch an.", "Help anyway -- leaving Lisa hanging feels wrong.")
    $ choice_stay_focused = t("Ablehnen und an BühlerTube bleiben.", "Decline and stay on BühlerTube.")

    menu:
        "[choice_help_lisa]":
            $ apply_extra_event_penalty()
            scene lernlandschaft at time_tint()
            show lisa filming
            show lisa thumbsup
            $ lisa(t("Danke dir, das rette ich mir gut.", "Thanks, you're a lifesaver."))
            scene vtsei at time_tint()
        "[choice_stay_focused]":
            $ apply_decline_event_effect()
            $ lisa(t("Kein Problem, ich frage jemand anderen.", "No problem, I'll ask someone else."))
    hide lisa

    $ current_time = 13
    $ next_label = "day12_after_afternoon_slot"
    jump slot_event_or_project

label day12_after_afternoon_slot:
    $ current_time = 18
    show tom normal
    $ tom(t("Guter Einsatz heute, [player_name]. Ich merke, dass du reingewachsen bist.", "Good effort today, [player_name]. I can tell you've grown into this."))
    $ p(t("Danke, das bedeutet mir viel.", "Thanks, that means a lot."))
    hide tom
    jump end_of_day


label montage_final_stretch:
    $ days_left = deadline_day - current_day - 1
    if days_left < 1:
        $ days_left = 1

    $ current_time = 9
    $ new_day_scene()

    $ p(t("Die letzten Tage vor der Abgabe verschwimmen zu einem einzigen Blur aus Arbeit.", "The last days before the deadline blur into a single stretch of work."))
    show nicola normal:
        pos_nicola
    $ boss(t("Endspurt! Bringt es zu Ende.", "Final stretch! Bring it home."))
    hide nicola

    $ montage_drift(days_left)
    $ current_day += days_left
    $ current_time = 18

    $ p(t("Und dann, praktisch über Nacht, ist es plötzlich der letzte Tag.", "And then, almost overnight, it's suddenly the last day."))
    jump end_of_day


label day_final:
    $ current_time = 9
    $ team_working = True

    $ new_day_scene()

    $ p(t("Heute ist der Tag. Die Abgabe steht bevor.", "Today is the day. The submission is coming up."))
    show tom show
    $ tom(t("Letzte Chance für Feinschliff. Was machst du noch?", "Last chance for polish. What are you doing with it?"))

    $ choice_polish = t("Letzte Details polieren.", "Polish the final details.")
    $ choice_push_features = t("Noch schnell ein Feature reinquetschen.", "Squeeze in one more feature.")
    $ choice_rest = t("Nichts mehr riskieren, so lassen wie es ist.", "Not risk anything, leave it as is.")

    menu:
        "[choice_polish]":
            $ apply_project_work_choice("focus_quality")
        "[choice_push_features]":
            $ apply_project_work_choice("focus_quantity")
        "[choice_rest]":
            $ p(t("Ich lasse es, wie es ist, und atme kurz durch.", "I leave it as it is, and take a breath."))
    hide tom

    $ current_time = 12
    show nicola normal:
        pos_nicola
    $ boss(t("Wie steht ihr da, kurz vor Schluss?", "How are you looking, right before the end?"))
    $ p(t("Wir sind bereit, so gut es geht.", "We're as ready as we can be."))
    hide nicola

    jump project_submission


label end_of_day:
    $ current_day += 1

    if quantity >= 100:
        $ project_finished = True

    if current_day > deadline_day or project_finished:
        jump project_submission
    elif current_day == 3:
        jump day_3
    elif current_day == 4:
        jump day_4
    elif current_day == 5:
        jump montage_day5
    elif current_day == 6:
        jump day_6
    elif current_day == 7:
        jump montage_day7
    elif current_day == 8:
        jump day_8
    elif current_day in (9, 10, 11):
        jump montage_9_to_11
    elif current_day == 12:
        jump day_12
    elif current_day >= deadline_day - 1:
        jump day_final
    else:
        jump montage_final_stretch


label project_submission:
    show lisa normal:
        pos_nicola
    $ lisa(t("So, die drei Wochen sind um. Zeigt mir mal, was ihr geschafft habt.", "Alright, the three weeks are up. Show me what you've got."))
    $ p(t("Hier ist unser Ergebnis: BühlerTube.", "Here's our result: BühlerTube."))
    jump calculate_ending


init python:
    def get_speed_axis():
        if speed >= 70:
            return "fast"
        elif speed >= 40:
            return "normal"
        else:
            return "slow"

    def get_quality_axis():
        if quality >= 70:
            return "good"
        elif quality >= 40:
            return "medium"
        else:
            return "bad"

    def get_quantity_axis():
        if quantity >= 70:
            return "many_features"
        elif quantity >= 40:
            return "some_features"
        else:
            return "few_features"

    def count_high_stats():
        return sum(1 for v in (speed, quality, quantity) if v >= 70)

    def count_low_stats():
        return sum(1 for v in (speed, quality, quantity) if v < 40)

    def get_ending_key():
        return "%s_%s_%s" % (
            get_speed_axis(),
            get_quality_axis(),
            get_quantity_axis(),
        )

screen ending_stats_screen():
    zorder 190
    frame:
        xalign 0.5
        yalign 0.60
        background "#000000aa"
        padding (24, 14)
        hbox:
            spacing 30
            vbox:
                xsize 200
                text t("Qualität", "Quality") size 22 color "#ffffff" xalign 0.5
                text "[quality]/100" size 22 color "#ffffff" xalign 0.5
            vbox:
                xsize 200
                text t("Tempo", "Speed") size 22 color "#ffffff" xalign 0.5
                text "[speed]/100" size 22 color "#ffffff" xalign 0.5
            vbox:
                xsize 200
                text t("Umfang", "Quantity") size 22 color "#ffffff" xalign 0.5
                text "[quantity]/100" size 22 color "#ffffff" xalign 0.5

label calculate_ending:
    show screen ending_stats_screen

    if count_high_stats() >= 2:
        jump ending_two_or_more_strong
    elif count_low_stats() >= 2:
        jump ending_two_or_more_weak

    $ ending_key = get_ending_key()

    if ending_key == "fast_good_many_features":
        jump ending_fast_good_many
    elif ending_key == "fast_good_some_features":
        jump ending_fast_good_some
    elif ending_key == "fast_good_few_features":
        jump ending_fast_good_few
    elif ending_key == "fast_medium_many_features":
        jump ending_fast_medium_many
    elif ending_key == "fast_bad_many_features":
        jump ending_fast_bad_many
    elif ending_key == "slow_good_many_features":
        jump ending_slow_good_many
    elif ending_key == "slow_good_few_features":
        jump ending_slow_good_few
    elif ending_key == "slow_bad_few_features":
        jump ending_slow_bad_few
    else:
        jump ending_generic


label ending_two_or_more_strong:
    $ strong_areas = []
    if speed >= 70:
        $ strong_areas.append(t("Tempo", "Speed"))
    if quality >= 70:
        $ strong_areas.append(t("Qualität", "Quality"))
    if quantity >= 70:
        $ strong_areas.append(t("Umfang", "Scope"))
    $ strong_areas_text = " & ".join(strong_areas)

    $ lisa(t("Das ist wirklich stark -- gleich in mehreren Bereichen habt ihr Bestwerte erreicht: [strong_areas_text].", "This is really strong -- you hit top marks in several areas at once: [strong_areas_text]."))
    $ p(t("Wir haben uns bewusst darauf konzentriert, und es hat sich ausgezahlt.", "We deliberately focused on that, and it paid off."))
    hide lisa
    show tom normal
    $ tom(t("Respekt, das sieht richtig gut aus.", "Respect, this looks really good."))
    hide tom
    $ show_ending_title(t("Starke Bilanz -- gleich mehrere eurer Werte stechen klar heraus. Ein Ergebnis, auf das ihr stolz sein könnt.", "Strong Results -- several of your values clearly stand out. A result you can be proud of."))
    hide screen ending_stats_screen
    return


label ending_two_or_more_weak:
    $ weak_areas = []
    if speed < 40:
        $ weak_areas.append(t("Tempo", "Speed"))
    if quality < 40:
        $ weak_areas.append(t("Qualität", "Quality"))
    if quantity < 40:
        $ weak_areas.append(t("Umfang", "Scope"))
    $ weak_areas_text = " & ".join(weak_areas)

    $ lisa(t("Es gab einige Herausforderungen, vor allem bei [weak_areas_text]. Das war sicher kein leichtes Projekt.", "There were some real challenges, especially with [weak_areas_text]. This definitely wasn't an easy project."))
    $ lisa(t("Lasst uns gemeinsam anschauen, wie wir das nächste Mal besser vorbereitet sind.", "Let's look together at how we can be better prepared next time."))
    hide lisa
    show tom normal
    $ tom(t("Hey, das war ein hartes Projekt. Aus so was lernt man am meisten.", "Hey, that was a tough project. That's exactly where you learn the most."))
    hide tom
    $ show_ending_title(t("Ein lehrreiches Projekt -- einige Bereiche blieben deutlich hinter den Erwartungen zurück. Kein Grund, den Kopf hängen zu lassen: Aus diesen Erfahrungen lässt sich beim nächsten Mal viel mitnehmen.", "A Learning Experience -- some areas clearly fell short of expectations. No reason to be discouraged: there's a lot to take from this into the next project."))
    hide screen ending_stats_screen
    return


label ending_fast_good_many:
    $ lisa(t("Das ist... beeindruckend. Schnell, sauber, und vollständig.", "This is... impressive. Fast, clean, and complete."))
    $ lisa(t("Ehrlich gesagt hätte ich das von einem Team in dieser Zeit nicht erwartet.", "Honestly, I didn't expect this from a team in this amount of time."))
    hide lisa
    show tom normal
    $ tom(t("Du hast das wirklich gerissen. Respekt.", "You really nailed this. Respect."))
    hide tom
    $ show_ending_title(t("Der Musterschüler -- ihr wart schnell, die Qualität stimmte, und ihr habt viele Funktionen geschafft. Alles lief perfekt zusammen.", "The Model Student -- you were fast, quality was strong, and you delivered many features. Everything came together perfectly."))
    hide screen ending_stats_screen
    return


label ending_fast_good_some:
    $ lisa(t("Solide Arbeit. Schnell und mit guter Qualität, auch wenn nicht alles Geplante drin ist.", "Solid work. Fast and with good quality, even if not everything planned made it in."))
    $ p(t("Wir haben Prioritäten gesetzt, und ich glaube, es war die richtige Wahl.", "We set priorities, and I think it was the right call."))
    hide lisa
    $ show_ending_title(t("Effizient und sauber -- ihr wart schnell und die Qualität war gut, dafür habt ihr auf einen Teil des Funktionsumfangs verzichtet. Ein gutes Ergebnis mit klugen Kompromissen.", "Efficient and Clean -- you were fast and quality was good, but you sacrificed some of the feature scope for it. A good result with smart compromises."))
    hide screen ending_stats_screen
    return


label ending_fast_good_few:
    $ lisa(t("Was ihr abgeliefert habt ist klein, aber wirklich gut gemacht.", "What you delivered is small, but really well made."))
    hide lisa
    show tom normal
    $ tom(t("Manchmal ist weniger mehr, oder?", "Sometimes less is more, right?"))
    hide tom
    $ show_ending_title(t("Klein, aber fein -- ihr wart schnell und die Qualität war hoch, aber der Funktionsumfang blieb klein. Qualität über Umfang.", "Small but Excellent -- you were fast and quality was high, but the feature scope stayed small. Quality over scope."))
    hide screen ending_stats_screen
    return


label ending_fast_medium_many:
    $ lisa(t("Ihr wart schnell und habt viel geschafft, auch wenn die Qualität stellenweise wackelt.", "You were fast and got a lot done, even if quality wobbles in places."))
    $ p(t("Wir wissen, wo die Schwachstellen sind. Die hätten wir mit mehr Zeit ausgebügelt.", "We know where the weak spots are. We'd have ironed those out with more time."))
    hide lisa
    $ show_ending_title(t("Viel geschafft, aber mit Kanten -- ihr wart schnell und habt viele Funktionen eingebaut, die Qualität blieb dabei aber nur mittelmässig. Ein funktionales, aber noch nicht ganz ausgereiftes Ergebnis.", "A Lot Done, but Rough Edges -- you were fast and packed in many features, but quality only ended up middling. A functional but not yet fully polished result."))
    hide screen ending_stats_screen
    return


label ending_fast_bad_many:
    $ lisa(t("Ihr wart schnell und habt viele Features reingepackt... aber die Qualität hat darunter gelitten.", "You were fast and packed in a lot of features... but quality suffered as a result."))
    hide lisa
    show tom normal
    $ tom(t("Ich glaube, das macht sich später bemerkbar, wenn jemand das wirklich benutzt.", "I think this will show later, once someone actually uses it."))
    hide tom
    $ show_ending_title(t("Quantität mit Nebenwirkungen -- ihr wart schnell und habt viele Funktionen geschafft, die Qualität ist dabei aber auf der Strecke geblieben. Viel drin, aber noch Luft nach oben bei der Feinarbeit.", "Quantity with Side Effects -- you were fast and delivered many features, but quality fell by the wayside. A lot packed in, but room to improve on the polish."))
    hide screen ending_stats_screen
    return


label ending_slow_good_many:
    $ lisa(t("Es hat länger gedauert als geplant, aber was ihr abliefert ist umfangreich und wirklich gut.", "It took longer than planned, but what you're delivering is extensive and really good."))
    $ p(t("Wir haben uns die Zeit genommen, die es gebraucht hat.", "We took the time it needed."))
    hide lisa
    $ show_ending_title(t("Gründlich bis zum Schluss -- ihr wart langsamer unterwegs, aber Qualität und Funktionsumfang sind beide hoch. Sorgfalt hat ihren Preis, aber sie hat sich gelohnt.", "Thorough to the End -- you moved slower, but both quality and scope came out high. Care took its time, but it paid off."))
    hide screen ending_stats_screen
    return


label ending_slow_good_few:
    if draft_chosen:
        $ lisa(t("Ihr wart gründlich mit dem Entwurf, aber am Ende ist weniger fertig geworden, als geplant war.", "You were thorough with the draft, but less ended up finished than planned."))
    else:
        $ lisa(t("Es ist weniger fertig geworden, als geplant war, aber was da ist, ist solide gemacht.", "Less got finished than planned, but what's there is solidly made."))
    hide lisa
    show tom normal
    $ tom(t("Qualität war euch wichtiger als Tempo. Das sieht man.", "Quality mattered more to you than speed. It shows."))
    hide tom
    $ show_ending_title(t("Der Perfektionist -- ihr wart langsam und der Funktionsumfang blieb klein, aber die Qualität war hoch. Lieber wenig, aber richtig.", "The Perfectionist -- you were slow and scope stayed small, but quality was high. Better little, but done right."))
    hide screen ending_stats_screen
    return


label ending_slow_bad_few:
    $ lisa(t("Das war leider keine einfache Projektphase. Es ist wenig fertig geworden, und auch bei der Qualität ist noch Luft nach oben.", "That was unfortunately not an easy project phase. Little got finished, and there's also room to improve on quality."))
    $ lisa(t("Lasst uns gemeinsam anschauen, was wir daraus lernen können.", "Let's look together at what we can learn from this."))
    hide lisa
    show tom normal
    $ tom(t("Hey, das war ein harter Start. Beim nächsten Projekt wird's besser.", "Hey, that was a rough start. It'll go better on the next project."))
    hide tom
    $ show_ending_title(t("Der harte Weg -- Tempo, Qualität und Umfang blieben alle niedrig. Eine harte Lektion, aber eine wertvolle für das nächste Mal.", "The Hard Way -- speed, quality, and scope all stayed low. A tough lesson, but a valuable one for next time."))
    hide screen ending_stats_screen
    return


label ending_generic:
    $ lisa(t("Das Ergebnis ist solide -- ihr habt in allen drei Bereichen ein ausgewogenes Niveau erreicht, ohne grosse Ausreisser nach oben oder unten.", "The result is solid -- you reached a balanced level across all three areas, without big outliers in either direction."))
    $ p(t("Wir haben das Beste aus der Zeit und den Entscheidungen gemacht, die wir getroffen haben.", "We made the most of the time and the decisions we made."))
    hide lisa
    $ show_ending_title(t("Solide Balance -- eure Werte bei Tempo, Qualität und Umfang liegen alle in einem gesunden Mittelfeld. Ein rundes Ergebnis ganz ohne Schlagseite.", "Solid Balance -- your speed, quality, and scope all landed in a healthy middle ground. A well-rounded result without any weak spots."))
    hide screen ending_stats_screen
    return
