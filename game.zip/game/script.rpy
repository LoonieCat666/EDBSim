﻿# The script of the game goes in this file.

# ------------------------------------------------------------
# LANGUAGE SETUP
# ------------------------------------------------------------
init python:
    if persistent.lang is None:
        persistent.lang = "de"  # default language: German

    def t(de, en):
        """Returns the German or English string depending on the
        currently selected language."""
        if persistent.lang == "en":
            return en
        return de

# A small overlay screen that lets the player switch language.
# It only shows up while the main menu screen is on screen, so it
# won't appear during actual gameplay.
screen language_picker():
    zorder 100
    if main_menu:
        hbox:
            xalign 1.0
            yalign 0.0
            xoffset -20
            yoffset 20
            spacing 10
            textbutton "Deutsch" action SetField(persistent, "lang", "de")
            textbutton "English" action SetField(persistent, "lang", "en")

init python:
    config.always_shown_screens.append("language_picker")


# ------------------------------------------------------------
# CHARACTERS
# ------------------------------------------------------------
# Tom is a fixed character.
define tom = Character("Tom")

# The player's own character. The name shown is whatever the
# player typed in ("[player_name]" is interpolated automatically).
define p = Character("[player_name]")

# Defaults, so the variables exist even before they're set.
default player_name = ""
default player_gender = "m"  # "m", "f" or "nb"


# ------------------------------------------------------------
# HELPER: get the pronoun for the current language + gender
# ------------------------------------------------------------
init python:
    def get_pronoun():
        subj = {
            "m":  ("er", "he"),
            "f":  ("sie", "she"),
            "nb": ("they", "they"),
        }
        obj = {
            "m":  ("ihn", "him"),
            "f":  ("sie", "her"),
            "nb": ("them", "them"),
        }
        idx = 0 if persistent.lang == "de" else 1
        return subj[player_gender][idx], obj[player_gender][idx]


# ------------------------------------------------------------
# THE GAME STARTS HERE
# ------------------------------------------------------------
label start:

    scene vtsei
    show tom normal: 
        zoom 2.0

    $ tom(t("Hallo! Ich bin Tom.", "Hello! I'm Tom."))
    $ tom(t("Wie heißt du?", "What's your name?"))

    $ player_name = renpy.input(t("Gib deinen Namen ein:", "Enter your name:"), length=20)
    $ player_name = player_name.strip()

    if player_name == "":
        $ player_name = t("Unbekannt", "Unknown")

    $ tom(t("Schön dich kennenzulernen, [player_name]!", "Nice to meet you, [player_name]!"))

    $ tom(t("Wie soll ich dich ansprechen?", "How should I refer to you?"))

    menu:
        "Männlich" if persistent.lang == "de":
            $ player_gender = "m"

        "Male" if persistent.lang == "en":
            $ player_gender = "m"

        "Weiblich" if persistent.lang == "de":
            $ player_gender = "f"

        "Female" if persistent.lang == "en":
            $ player_gender = "f"

        "Nicht-binär" if persistent.lang == "de":
            $ player_gender = "nb"

        "Non-binary" if persistent.lang == "en":
            $ player_gender = "nb"

    $ subj, obj = get_pronoun()

    $ tom(t("Alles klar, ich werde [player_name] als [subj] bezeichnen.", "Got it, I'll refer to [player_name] as [subj]."))

    show tom show:
        zoom 2.0
        xalign -6.0
        xzoom -1.0

    $ tom(t("Hier befinden wir und im VTSEI, der Abteilung in der wir Informatiker arbeiten.", "We are in the VTSEI, the department where we computer scientists work."))

    return